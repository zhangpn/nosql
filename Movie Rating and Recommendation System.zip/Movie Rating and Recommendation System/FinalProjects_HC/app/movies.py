'''Module for serving API requests'''

from flask import request, jsonify
from neo4j import GraphDatabase
import logging
from app import app  # Import the app object from __init__.py

# Set up logging
# logging.basicConfig(level=logging.INFO)

# Neo4j connection setup
URI = "bolt://localhost:7687"
USERNAME = "neo4j"
PASSWORD = "password"

# Initialize Neo4j Driver
try:
    driver = GraphDatabase.driver(URI, auth=(USERNAME, PASSWORD))
    logging.info("Connected to Neo4j successfully.")
except Exception as e:
    logging.error(f"Failed to connect to Neo4j: {str(e)}")
    driver = None


# Close Neo4j driver on app teardown
# @app.teardown_appcontext
# def close_driver(exception):
#     if driver:A
#         driver.close()
#         logging.info("Neo4j driver closed.")

# import databases

# Root Route
# http://127.0.0.1:5002/
@app.route("/", methods=["GET"])
def home():
    return jsonify({"message": "Welcome to my movie rating and recommendation system!"})

# Test Route
# http://127.0.0.1:5002/test
@app.route('/test', methods=['GET'])
def test_route():
    logging.info("Test route accessed!")
    return jsonify({"message": "Test successful"})

# feature 1. Search by Movie ID Route
# http://127.0.0.1:5002/search_by_movie_id/3
@app.route("/search_by_movie_id/<movie_id>", methods=['GET'])
def get_movie_by_id(movie_id):
    logging.info(f"Received request for movie_id: {movie_id}")
    try:
        query = '''
            MATCH (b:Movie {movieID:$movieID})
            RETURN b.movieID AS id, b.movieTitle AS title, b.Genre AS genre
        '''
        with driver.session() as session:
            result = session.run(query, movieID=movie_id)
            movie_details = result.data()

        if not movie_details:
            return jsonify({"message": "Movie not found"}), 404

        return jsonify(movie_details)

    except Exception as e:
        logging.error(f"Error fetching movie details: {str(e)}")
        return jsonify({"error": str(e)}), 500

# feature 2. Search by movie ID and rater ID, see the rating of specific user towards specific movie (search by userID)
# http://127.0.0.1:5002/search_rating_by_movie_rater_id/242/196
@app.route("/search_rating_by_movie_rater_id/<movie_id>/<rater_id>", methods=['GET'])
def get_rating_by_movie_rater_id(movie_id,rater_id):
    logging.info(f"Received request for movie_id: {movie_id}, rater_id: {rater_id}")
    try:
        query = '''
            MATCH (a:User {userID: $userID}) -[r:RATING]->(b:Movie{movieID:$movieID})
            RETURN DISTINCT a.userID AS userID, r.score AS score, r.time AS time, b.movieID, b.movieTitle
        '''
        with driver.session() as session:
            result = session.run(query, userID = rater_id,movieID=movie_id)
            rating_details = result.data()

        if not rating_details:
            return jsonify({"message": "Rating not found"}), 404

        return jsonify(rating_details)

    except Exception as e:
        logging.error(f"Error fetching rating details: {str(e)}")
        return jsonify({"error": str(e)}), 500

# feature 3. Search by rater ID, see the rating of specific user towards all movies (search by userID)
# http://127.0.0.1:5002/search_rating_by_rater_id/242
@app.route("/search_rating_by_rater_id/<rater_id>", methods=['GET'])
def get_rating_by_rater_id(rater_id):
    logging.info(f"Received request for rater_id: {rater_id}")
    try:
        query = '''
            MATCH (a:User {userID: $userID}) -[r:RATING]->(b:Movie)
            RETURN a.userID AS userID, r.score AS score, r.time AS time, b.movieID as movieID, b.movieTitle as title
            ORDER BY score DESC
        '''
        with driver.session() as session:
            result = session.run(query, userID = rater_id)
            rating_details = result.data()

        if not rating_details:
            return jsonify({"message": "Rating not found"}), 404

        return jsonify(rating_details)

    except Exception as e:
        logging.error(f"Error fetching rating details: {str(e)}")
        return jsonify({"error": str(e)}), 500

# feature 4. update the rating for a movie by a user
# http://127.0.0.1:5002/update_rating_by_movie_rater_id/<movie_id>/<rater_id>/<rating>
@app.route("/update_rating_by_movie_rater_id/<movie_id>/<rater_id>/<rating_score>", methods=['POST'])
def update_rating_by_movie_rater_id(movie_id, rater_id, rating_score):
    logging.info(f"Received request for movie_id:{movie_id},rater_id: {rater_id},rating:{rating_score}")
    try:
        query = '''
            MERGE (a:User {userID:$userID})-[r:RATING]->(b:Movie {movieID:$movieID})
                ON MATCH SET r.time = toString(datetime()), r.score = $rating
                ON CREATE SET r.time = toString(datetime()), r.score = $rating
        '''
        with driver.session() as session:
            session.run(query, userID=rater_id, movieID=movie_id, rating=rating_score)

        return jsonify({"message":"Rating updated successfully"})

    except Exception as e:
        logging.error(f"Error updating rating details: {str(e)}")
        return jsonify({"error": str(e)}), 500


# feature 5. delete the rating for a movie by a user
# http://127.0.0.1:5002/delete_rating_by_movie_rater_id/<movie_id>/<rater_id>
@app.route("/delete_rating_by_movie_rater_id/<movie_id>/<rater_id>", methods=['DELETE'])
def delete_rating_by_movie_rater_id(movie_id, rater_id):
    logging.info(f"Received request for movie_id:{movie_id},rater_id: {rater_id}")
    try:
        query = '''
            MATCH (a:User {userID: $userID})-[r:RATING]->(b:Movie {movieID: $movieID})
            DELETE r
        '''
        with driver.session() as session:
            session.run(query, userID=rater_id, movieID=movie_id)

        return jsonify({"message":"Rating deleted successfully"})

    except Exception as e:
        logging.error(f"Error deleting rating: {str(e)}")
        return jsonify({"error": str(e)}), 500

# feature 6.1 check the average rating for all the movies
# http://127.0.0.1:5002/check_average_rating_for_all_movies/
@app.route("/check_average_rating_for_all_movies/", methods=['GET'])
def check_average_rating_for_all():
    logging.info("Start to work!")
    try:
        query = '''
            MATCH (a:User) -[r:RATING]->(b:Movie)
            WITH b.movieID AS movieID, HEAD(COLLECT(DISTINCT b.movieTitle)) AS movieTitle, AVG(toFloat(r.score)) AS averageScore
            ORDER BY averageScore DESC
            RETURN movieID, movieTitle, averageScore
        '''

        with driver.session() as session:
            result = session.run(query)
            # Extract results into a list of dictionaries
            ratings = [
                {"movieID": record["movieID"], "movieTitle": record["movieTitle"],
                 "averageScore": record["averageScore"]}
                for record in result
            ]

        return jsonify(ratings), 200

    except Exception as e:
        logging.error(f"Error fetching average: {str(e)}")
        return jsonify({"error": str(e)}), 500

# feature 6.2 check the average rating for a specific movie
# http://127.0.0.1:5002/check_average_rating_for_one_movie/<movieID>
@app.route("/check_average_rating_for_one_movie/<movieID>", methods=['GET'])
def check_average_rating_for_one(movieID):
    try:
        query = '''
            MATCH (a:User) -[r:RATING]->(b:Movie{movieID:$movieID})
            RETURN b.movieID AS movieID, b.movieTitle as movieTitle, AVG(toFloat(r.score)) AS averageScore
        '''

        with driver.session() as session:
            result = session.run(query,movieID=movieID)
            # Extract results into a list of dictionaries
            ratings = [
                {"movieID": record["movieID"], "movieTitle": record["movieTitle"],
                 "averageScore": record["averageScore"]}
                for record in result
            ]

        if not ratings:
            return jsonify({"message": f"No ratings found for movieID {movieID}"}),404

        return jsonify(ratings[0]), 200

    except Exception as e:
        logging.error(f"Error fetching average: {str(e)}")
        return jsonify({"error": str(e)}), 500

# feature 7. check the average rating by genres
# http://127.0.0.1:5002/check_average_rating_by_genres/
@app.route("/check_average_rating_by_genres/", methods=['GET'])
def check_average_rating_by_genres():
    logging.info("Start to work!")
    try:
        query = '''
            MATCH (a:User) -[r:RATING]->(b:Movie)
            WITH b.Genre AS Genre, AVG(toFloat(r.score)) AS averageScore
            ORDER BY averageScore DESC
            RETURN Genre, averageScore

        '''

        with driver.session() as session:
            result = session.run(query)
            # Extract results into a list of dictionaries
            ratings = [
                {"Genre": record["Genre"],
                 "averageScore": record["averageScore"]}
                for record in result
            ]

        return jsonify(ratings), 200

    except Exception as e:
        logging.error(f"Error fetching average: {str(e)}")
        return jsonify({"error": str(e)}), 500

# feature 8. calculate similarity score to recommend movies
# http://127.0.0.1:5002/recommend_movies?user_input=196&movies_selected=6&movies_selected=7&movies_selected=9
@app.route("/recommend_movies", methods=['GET'])
def recommend_movies():
    logging.info("Received request for movie recommendations")
    try:
        # Get inputs from query parameters
        user_input = request.args.get('user_input')
        movies_selected = request.args.getlist('movies_selected')

        # Validate inputs
        if not user_input or not movies_selected:
            return jsonify({"error": "Both 'user_input' and 'movies_selected' parameters are required"}), 400

        # Generate a list of all users except the current one
        users_all = list(map(str, range(1, 944)))  # Assuming user IDs are from 1 to 943
        other_user_list = [user for user in users_all if user != user_input]

        recommendations = []

        with driver.session() as session:
            for movie_each in movies_selected:
                recommendationScore = 0

                for userID_each in other_user_list:
                    # Calculate weight (Jaccard score)
                    query_weight = '''
                                MATCH (a1:User{userID:$user_input}) -[:RATING]->(b:Movie{movieID:$movieID})<-[:RATING]-(a2:User{userID: $userID})
                                WITH COUNT(DISTINCT b) AS overlappingMovies
                                MATCH (a:User)-[:RATING]->(c:Movie)
                                WHERE a.userID IN [$userID, $user_input]
                                WITH overlappingMovies, COUNT(DISTINCT c) AS totalMovies
                                RETURN toFloat(overlappingMovies)/totalMovies AS JScore
                            '''
                    weight_result = session.run(query_weight, user_input=user_input, userID=userID_each,
                                                movieID=movie_each).values()

                    if weight_result:  # If weight exists
                        weight_final = float(weight_result[0][0])
                    else:
                        weight_final = 0

                    # Get rating score
                    query_score = '''
                                MATCH (a:User{userID:$userID}) -[r:RATING]->(b:Movie{movieID:$movieID})
                                RETURN r.score
                            '''
                    score_result = session.run(query_score, userID=userID_each, movieID=movie_each).values()

                    if score_result:  # If score exists
                        score_final = float(score_result[0][0])
                    else:
                        score_final = 0

                    # Add to recommendation score (weighted sum)
                    recommendationScore += weight_final * score_final

                # Append movie recommendation result
                recommendations.append({
                    "movieID": movie_each,
                    "recommendationScore": recommendationScore
                })

        # Sort recommendations by score in descending order
        recommendations = sorted(recommendations, key=lambda x: x['recommendationScore'], reverse=True)

        return jsonify(recommendations), 200

    except Exception as e:
        logging.error(f"Error in movie recommendation logic: {str(e)}")
        return jsonify({"error": str(e)}), 500

# feature 9. recommend users of same tastes
# http://127.0.0.1:5002/recommend_users?user_input=196&movie_in_common=5&number_users=10
@app.route("/recommend_users", methods=['GET'])
def recommend_users():
    logging.info("Received request for movie recommendations")
    try:
        # Get inputs from query parameters
        user_input = request.args.get('user_input')
        movie_in_common = request.args.get('movie_in_common', type=int)
        number_users = request.args.get('number_users', type=int)

        # Validate inputs
        if not user_input or not movie_in_common or not number_users:
            return jsonify({"error": "Parameters 'user_input', 'movie_in_common', and 'number_users' are required"}), 400

        query = '''
                    MATCH (a1:User {userID: $userID})-[r1:RATING]->(m:Movie)<-[r2:RATING]-(a2:User)
                    WHERE a1 <> a2
                    WITH a2.userID AS similarUserID, 
                         SUM(ABS(toFloat(r1.score) - toFloat(r2.score))) AS totalDifference, 
                         COUNT(m) AS numberCommonMovies
                    WHERE numberCommonMovies >= $movieInCommon
                    RETURN similarUserID, totalDifference
                    ORDER BY totalDifference ASC
                    LIMIT $numberUsers
                '''

        with driver.session() as session:
            result = session.run(
                query,
                userID=user_input,
                movieInCommon=movie_in_common,
                numberUsers=number_users
            )
            recommendations = [
                {"similarUserID": record["similarUserID"],
                 "totalDifference": record["totalDifference"]}
                for record in result
            ]

        # If no recommendations found
        if not recommendations:
            return jsonify({"message": "No similar users found"}), 404

        # Return recommendations
        return jsonify(recommendations), 200

    except Exception as e:
        logging.error(f"Error in user recommendation logic: {str(e)}")
        return jsonify({"error": str(e)}), 500

# feature 10. get most rated movies
# http://127.0.0.1:5002/get_most_rated_movies/
@app.route("/get_most_rated_movies/", methods=['GET'])
def get_most_rated_movies():
    try:
        query = '''
                    MATCH (b:Movie)-[r:RATING]-(a:User)
                    WITH b.movieID AS movieID, b.movieTitle AS movieTitle, COUNT(r) AS ratingCount
                    RETURN movieID, movieTitle, ratingCount
                    ORDER BY ratingCount DESC
                '''

        with driver.session() as session:
            result = session.run(query)
            movies = [
                {"movieID": record["movieID"],
                 "movieTitle": record["movieTitle"],
                 "ratingCount": record["ratingCount"]}
                for record in result
            ]

        # Return recommendations
        return jsonify(movies), 200

    except Exception as e:
        logging.error(f"Error fetching most-rated movies: {str(e)}")
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)

