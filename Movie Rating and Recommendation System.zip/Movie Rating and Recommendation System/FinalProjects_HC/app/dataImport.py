'''Module for serving API requests'''

from flask import request, jsonify
from neo4j import GraphDatabase
import logging
from app import app  # Import the app object from __init__.py

# Set up logging
# logging.basicConfig(level=logging.INFO)

# Neo4j connection setup
URI = "bolt://localhost:7687"
USERNAME = "neo4j"
PASSWORD = "password"

# Initialize Neo4j Driver
try:
    driver = GraphDatabase.driver(URI, auth=(USERNAME, PASSWORD))
    logging.info("Connected to Neo4j successfully.")
except Exception as e:
    logging.error(f"Failed to connect to Neo4j: {str(e)}")
    driver = None


# Close Neo4j driver on app teardown
# @app.teardown_appcontext
# def close_driver(exception):
#     if driver:
#         driver.close()
#         logging.info("Neo4j driver closed.")

# import databases

# import user ratings data
def import_ratings():
    query = '''
        LOAD CSV WITH HEADERS FROM 'file:///user_rating_data.csv' AS row
        MERGE (a:User {userID: row.userID})
        MERGE (b:Movie {movieID: row.movieID})

        MERGE (a)-[r:RATING]->(b)
            ON CREATE SET r.time = row.timestamp,
                          r.score = row.rating
            ON MATCH SET r.time = row.timestamp, 
                 r.score = row.rating 
    '''
    print("start here1")
    with driver.session() as session:
        session.run(query)
    print("here1")

# import user demographic data
def import_user_demographic():
    query = '''
        LOAD CSV WITH HEADERS FROM 'file:///user_demographic_data.csv' AS row
        MERGE (a:User {userID: row.userID})
          ON CREATE SET a.age = row.age,
                        a.gender = row.gender,
                        a.occuptation = row.occupation,
                        a.zipcode = toInteger(row.zipcode)
          ON MATCH SET a.age = row.age,
                       a.gender = row.gender,
                       a.occupation = row.occupation,
                       a.zipcode = toInteger(row.zipcode)
    '''
    with driver.session() as session:
        session.run(query)
    print("here2")

# import movies
def import_movies():
    query = '''
        LOAD CSV WITH HEADERS FROM 'file:///movie_data.csv' AS row
        MERGE (b:Movie {movieID: row.movieID})
          ON CREATE SET b.movieTitle = row.movieTitle,
                        b.Genre = row.Genre
          ON MATCH SET b.movieTitle = row.movieTitle,
                       b.Genre = row.Genre
    '''
    with driver.session() as session:
        session.run(query)
    print("here3")

if __name__ == "__main__": # code will not run if the file is imported and will run only when the script is executed directly
    import_ratings()
    import_user_demographic()
    import_movies()

# def greet():
#     print("Hello!")
#
# if __name__ == "__main__":
#     print("Running directly!")
#     greet()

# python example.py
# Running directly!
# Hello!

# from example import greet
# greet()
# Hello!

# plan: run-app.py
