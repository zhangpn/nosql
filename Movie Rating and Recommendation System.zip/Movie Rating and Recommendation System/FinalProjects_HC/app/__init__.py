from flask import Flask #flask-library, Flask- method/ anything inside the library

# __name__ is the package name - 'app', for locating templates and static files
app = Flask(__name__)

from app import movies
# in run-app.py, you can use  response = movies.get_movie_details(1)  # Call the function from the imported module
# we define our app here, shift our flow into customers