from app import app
from app.dataImport import import_movies, import_user_demographic, import_ratings

# this file is running the app- first app-folder, second app-init file

if __name__ == '__main__':
    ''' 
        Running app in debug mode
        It will trace errors if produced and display them
        Each time a change is made in code, the changes will reflect instantaneously. 
    '''

    import_ratings()
    import_user_demographic()
    import_movies()

    app.run(debug=True,port=5002)

# this starts the app(=flask application)