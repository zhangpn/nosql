# NoSQL Final Project

**Author: Xuhui Zhan**

**Email: xuhui.zhan@vanderbilt.edu**



## Usage

1. Make sure you have docker server running, by runing `docker ps` if there is valid output
2. Modify the line 18 in the `docker.yml`, replace the path `/Users/xuhuizhan/homework/NoSQL/mini_project` by your corresponding path of the folder containing both the `docker.yml` and `mp1_chatbot.py`![Screenshot 2024-09-27 at 6.58.10 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 6.58.10 PM.png)
3. Open a terminal, navigate to the current folder and run `docker compose up` (This command is for Mac which is the development platform, for other platform, there are similar commands like `docker-compose up`)
4. Open a <u>new</u> terminal, navigate to the current folder and run `docker compose exec -it python-app bash`
5. Within the latest terminal, run `pip install -r requirements.txt`
6. Also make sure you have the `api_key.json` completed by using `api_key_template.json`, by given you OPENAI_API key from https://platform.openai.com/docs/overview and owm_api_key from https://www.weatherapi.com/ 
7. Within the latest terminal, run `python fp_chatbot.py` and then you could start to chat!

## At the very beginning

The program will fetch stock history from 2024-01-01 till today for the pre-set companies from Yahoo finance and save the relevant data to redis database.

![Screenshot 2024-12-01 at 6.34.17 AM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-12-01 at 6.34.17 AM.png)

## Instructions on commands and options

### Commands

`!help`: List all the commands as: ![Screenshot 2024-09-27 at 7.13.51 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.13.51 PM.png)

`!weather <city>`: Replace the `<city>` with the city you would like to update, it would output the city weather if there is data existed, if not it would try to fetch data from open weather api, else it would instructed you the available options. The data would always be most recent and updated when return. It will also show yesterday' s weather of that city if in database.

![Screenshot 2024-09-27 at 7.16.02 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.16.02 PM.png)

`!stock` You could then input the interested company, the chatbot would then plot the stock price for saved data related to the interested company if exists in database.

![Screenshot 2024-12-01 at 6.33.35 AM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-12-01 at 6.33.35 AM.png)

`!fact` Output the random fact about the chatbot

![Screenshot 2024-09-27 at 7.18.00 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.18.00 PM.png)

`!whoami` Output the user information of current user you identified![Screenshot 2024-09-27 at 7.34.41 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.34.41 PM.png)

`!4` Send a message anonymously, the message will have a username as Anonymous

![Screenshot 2024-09-27 at 7.35.17 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.35.17 PM.png)

### ![Screenshot 2024-09-27 at 7.35.53 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.35.53 PM.png)Options

`1` Identify the current user as

![Screenshot 2024-09-27 at 7.22.13 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.22.13 PM.png)

`2` Join a channel, if you haven' t identify yourself using option `1`, it would ask you to do first, you would need to specified the name you would like to join first.

After you join, it will:

1. Send a message to the channel you join to indicate you are joined with the username identified before
2. Listen to the specific channel, and output messages from it. (By threading, during the listening, you could still type)
3. Based on what you type:

`!history`: Show the chat history of this channel (Only contains the ones being successfully subscribed)

![Screenshot 2024-09-27 at 7.26.30 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.26.30 PM.png)

`!leave`: Leave the channel and stop the listenning thread.

![Screenshot 2024-09-27 at 7.28.14 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.28.14 PM.png)

`!mimic tone`: Chatbot will mimic a specific user' s tone based on the chatting history of current channel, by leveraging openai api and prompt engineering (The user to mimic should be a real user in the history or in system, the user info would be given to gpt for better mimicking). (You could type `!leave` to return to channel instead of chat with the bot mimicing a user)

![Screenshot 2024-12-01 at 4.09.09 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-12-01 at 4.09.09 PM.png)

Other messages: Directly sent to the current channel

![Screenshot 2024-09-27 at 7.27.41 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.27.41 PM.png)

`3` Leave a channel, it would delete the channel you subscribe in the redis database, which record what channels specific user join as a set for each user. Users listenning to the channel would receive a message indicating you left.![Screenshot 2024-09-27 at 7.30.20 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.30.20 PM.png)

`4` Send a message to a channel

![Screenshot 2024-09-27 at 7.31.18 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.31.18 PM.png)

`5` Get information about a user

![Screenshot 2024-09-27 at 7.32.35 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.32.35 PM.png)

`6` Exit the chat room, which will close the program

![Screenshot 2024-09-27 at 7.37.14 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.37.14 PM.png)

`7` Listen to channels by pattern, any channel have this kind of pattern would be subsribed and output the messages.





### Monitor

Here shows all the activities monitoring by redis-cli when I created the demonstration in the above steps:

![Screenshot 2024-09-27 at 7.43.02 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.43.02 PM.png)

![Screenshot 2024-09-27 at 7.43.21 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.43.21 PM.png)

![Screenshot 2024-09-27 at 7.43.35 PM](/Users/xuhuizhan/Library/Application Support/typora-user-images/Screenshot 2024-09-27 at 7.43.35 PM.png)

## Database related queries

1. Set value by key
2. Set value by key and expiration time
3. Fetch value by key
4. Fetch a set by key
5. Add value to a set by key and value
6. Subsribe to a channel
7. Publish messages to a channel
8. Unsubscribe from a channel
9. Set a list by key
10. Add a value to a list by key and value
11. Etc..

## What makes it special

1. A new option as `7` to listen to multiple channels by patterns
2. `!weather` that could try to fetch data from open weather api if not existed, it will also show yesterday' s weather if saved
3. A new command as `!4` to send messages annoymously
4. Multi-thread desgins with special commands as `!history` and `!leave` enabling to publish message while listening
5. Special `!history` command is enabled by saving history messages into a list with designed key
6. Special `!mimic tone` command by leveraging openai api and prompt engineering
7. Special `!stock` that would plot the history price for interested company directly in terminal

## Challenges and How They Were Addressed

#### 1. Integrating Real-Time Data
- **Challenge**: Ensuring accurate and up-to-date data for weather and stock information, plot in terminal
- **Solution**: Checked Redis for existing data, fetched updates from APIs if missing, and stored the results back in Redis, use plotext to enable ploting the price change in terminal directly.

#### 2. Enabling Multi-Threaded Communication
- **Challenge**: Allowing users to listen to channels and interact without interruption.
- **Solution**: Added threading to support simultaneous channel listening and command execution. Set timeout for listening event to ensure smooth interruption.

#### 3. Managing Redis Data Efficiently
- **Challenge**: Handling large volumes of data for channels, messages, and user interactions.
- **Solution**: Designed Redis schemas with clear structures for storing and retrieving sets, lists, and keys with expiration policies.

#### 4. Ensuring Recent Weather Data Storage
- **Challenge**: Storing only the most recent weather data without overwriting or holding stale data.
- **Solution**: Calculated the time-to-live (TTL) dynamically using `datetime` by determining the seconds until midnight. Integrated this into the Redis storage mechanism to adjust the TTL dynamically for each weather update.

#### 5. Using OpenAI for Tone Mimicking
- **Challenge**: Generating chatbot responses that mimic user tones based on chat history.
- **Solution**: Leveraged OpenAI’s API with carefully crafted prompts to achieve consistent and relevant tone mimicking.

#### 6. User-Friendly Commands and Interactivity
- **Challenge**: Providing a range of functionalities without overwhelming the user.
- **Solution**: Developed clear commands like `!weather`, `!stock`, and `!mimic tone`, ensuring documentation was easy to follow.

## Summary

The **NoSQL Final Project** is a chatbot that combines data scraping, API calls, Redis database operations, and OpenAI’s language model to create a functional and interactive system. It allows users to fetch weather updates, plot stock prices, send messages (including anonymously), and mimic user tones based on chat history. Multi-threading ensures smooth real-time interactions in chatrooms, letting users send messages and execute commands simultaneously. Redis is used to store and manage chat history, user data, and channel subscriptions efficiently. 

The project stands out with features like dynamic weather and stock data fetching, multi-channel listening based on patterns, and the ability to mimic user tones using OpenAI’s API and prompt engineering. It offers a practical and responsive system for communication and data management.

