from flask import Blueprint, jsonify, session, current_app
from datetime import datetime, timedelta
from bson.objectid import ObjectId
from app.analysis.patterns import TransactionPatternAnalyzer

analysis_bp = Blueprint('analysis', __name__)

def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"error": "Authentication required"}), 401
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

@analysis_bp.route('/api/analysis/recurring')
@login_required
def get_recurring_transactions():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"error": "Not authenticated"}), 401
    
    analyzer = TransactionPatternAnalyzer(current_app.db)
    patterns = analyzer.detect_recurring_transactions(user_id)
    
    return jsonify(patterns)

@analysis_bp.route('/api/analysis/unusual')
@login_required
def get_unusual_transactions():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"error": "Not authenticated"}), 401
    
    analyzer = TransactionPatternAnalyzer(current_app.db)
    unusual = analyzer.detect_unusual_transactions(user_id)
    
    return jsonify(unusual)

@analysis_bp.route('/api/analysis/trends')
@login_required
def get_spending_trends():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"error": "Not authenticated"}), 401
    
    analyzer = TransactionPatternAnalyzer(current_app.db)
    trends = analyzer.analyze_spending_trends(user_id)
    
    return jsonify(trends)