from app import create_app
from data_generator import generate_sample_data
from bson.objectid import ObjectId
import argparse
from datetime import datetime


app = create_app()

def init_sample_data(user_id=None, days=90):
    """Initialize the database with sample transaction data"""
    with app.app_context():
        if user_id is None:
            # Create a test user if user_id is not provided
            test_password = "testpassword123"
            result = app.db.users.insert_one({
                "email": "test@example.com",
                "password_hash": 'test_hash',
                "created_at": datetime.utcnow()
            })
            user_id = result.inserted_id
        
        # Generate and insert sample transactions
        transactions = generate_sample_data(user_id, num_days=days)
        if transactions:
            app.db.transactions.insert_many(transactions)
            print(f"Generated {len(transactions)} sample transactions for user {user_id}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Run the Personal Finance Pattern Analyzer')
    parser.add_argument('--init-db', action='store_true', help='Initialize database with sample data')
    parser.add_argument('--days', type=int, default=90, help='Number of days of sample data to generate')
    parser.add_argument('--port', type=int, default=5000, help='Port to run the application on')
    parser.add_argument('--debug', action='store_true', help='Run in debug mode')
    
    args = parser.parse_args()
    
    if args.init_db:
        print("Initializing database with sample data...")
        init_sample_data(days=args.days)
        print("Database initialized successfully!")
    
    # Run the Flask application
    app.run(debug=args.debug, port=args.port)