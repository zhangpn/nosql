from flask import jsonify, request, session
from werkzeug.security import generate_password_hash, check_password_hash
from app.api import bp
from datetime import datetime
from bson.objectid import ObjectId

@bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    
    # Validate input
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({"error": "Missing required fields"}), 400
        
    # Check if user already exists
    if current_app.db.users.find_one({"email": data['email']}):
        return jsonify({"error": "Email already registered"}), 400
    
    # Create new user
    user = {
        "email": data['email'],
        "password_hash": generate_password_hash(data['password']),
        "created_at": datetime.utcnow()
    }
    
    # Insert user into database
    result = current_app.db.users.insert_one(user)
    
    return jsonify({
        "message": "User registered successfully",
        "user_id": str(result.inserted_id)
    }), 201

@bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({"error": "Missing required fields"}), 400
    
    user = current_app.db.users.find_one({"email": data['email']})
    
    # Verify password and create session
    if user and check_password_hash(user['password_hash'], data['password']):
        session['user_id'] = str(user['_id'])
        return jsonify({
            "message": "Login successful",
            "user_id": str(user['_id'])
        }), 200
        
    return jsonify({"error": "Invalid credentials"}), 401

@bp.route('/logout', methods=['POST'])
def logout():
    # Clear session
    session.clear()
    return jsonify({"message": "Logged out successfully"}), 200

def is_authenticated():
    return 'user_id' in session