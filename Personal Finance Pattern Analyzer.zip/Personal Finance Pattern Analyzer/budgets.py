from flask import jsonify, request, current_app, session
from app.api import bp
from datetime import datetime
from bson.objectid import ObjectId

def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"error": "Authentication required"}), 401
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

@bp.route('/budgets', methods=['POST'])
@login_required
def create_budget():
    user_id = session['user_id']
    data = request.get_json()
    
    # Validate required fields
    if not data or not all(k in data for k in ['category', 'monthly_limit']):
        return jsonify({"error": "Missing required fields"}), 400
        
    # Prepare budget document
    budget = {
        "user_id": ObjectId(user_id),
        "category": data['category'],
        "monthly_limit": float(data['monthly_limit']),
        "alerts_enabled": data.get('alerts_enabled', True),
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    
    try:
        # Update or create budget
        result = current_app.db.budgets.update_one(
            {
                "user_id": ObjectId(user_id), 
                "category": data['category']
            },
            {"$set": budget},
            upsert=True
        )
        
        return jsonify({
            "message": "Budget updated successfully",
            "category": data['category'],
            "monthly_limit": float(data['monthly_limit'])
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@bp.route('/budgets/tracking', methods=['GET'])
@login_required
def get_budget_tracking():
    user_id = session['user_id']
    
    # Get current month's start date
    today = datetime.utcnow()
    month_start = datetime(today.year, today.month, 1)
    
    try:
        # Get all budgets for the user
        budgets = list(current_app.db.budgets.find({"user_id": ObjectId(user_id)}))
        
        # Calculate current spending for each category
        pipeline = [
            {
                "$match": {
                    "user_id": ObjectId(user_id),
                    "date": {"$gte": month_start}
                }
            },
            {
                "$group": {
                    "_id": "$category",
                    "total_spent": {"$sum": "$amount"}
                }
            }
        ]
        
        spending = {
            item['_id']: item['total_spent']
            for item in current_app.db.transactions.aggregate(pipeline)
        }
        
        # Prepare budget tracking response
        tracking = []
        for budget in budgets:
            category = budget['category']
            monthly_limit = budget['monthly_limit']
            spent = spending.get(category, 0)
            
            tracking.append({
                "category": category,
                "monthly_limit": monthly_limit,
                "spent": spent,
                "remaining": monthly_limit - spent,
                "percentage_used": round((spent / monthly_limit * 100) if monthly_limit > 0 else 0, 2),
                "alerts_enabled": budget.get('alerts_enabled', True)
            })
        
        return jsonify(tracking), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Optional: Get a specific budget
@bp.route('/budgets/<category>', methods=['GET'])
@login_required
def get_budget(category):
    user_id = session['user_id']
    
    try:
        budget = current_app.db.budgets.find_one({
            "user_id": ObjectId(user_id),
            "category": category
        })
        
        if not budget:
            return jsonify({"error": "Budget not found"}), 404
            
        return jsonify({
            "category": budget['category'],
            "monthly_limit": budget['monthly_limit'],
            "alerts_enabled": budget.get('alerts_enabled', True)
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@bp.route('/budgets/<category>', methods=['DELETE'])
@login_required
def delete_budget(category):
    user_id = session['user_id']
    
    try:
        result = current_app.db.budgets.delete_one({
            "user_id": ObjectId(user_id),
            "category": category
        })
        
        if result.deleted_count == 0:
            return jsonify({"error": "Budget not found"}), 404
            
        return jsonify({
            "message": "Budget deleted successfully",
            "category": category
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400