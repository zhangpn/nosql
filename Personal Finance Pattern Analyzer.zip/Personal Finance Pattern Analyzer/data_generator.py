import random
from datetime import datetime, timedelta
import numpy as np
from faker import Faker

fake = Faker()

# Configure categories and merchants
CATEGORIES = [
    "Groceries", "Dining", "Transportation", "Entertainment", 
    "Shopping", "Utilities", "Healthcare", "Education"
]

MERCHANTS = {
    "Groceries": ["Whole Foods", "Trader Joe's", "Safeway", "Costco"],
    "Dining": ["McDonald's", "Chipotle", "Starbucks", "Local Restaurant"],
    "Transportation": ["Uber", "Lyft", "Gas Station", "Public Transit"],
    "Entertainment": ["Netflix", "Amazon Prime", "Movie Theater", "Concert Venue"],
    "Shopping": ["Amazon", "Target", "Walmart", "Best Buy"],
    "Utilities": ["Electric Company", "Water Service", "Internet Provider", "Phone Company"],
    "Healthcare": ["Pharmacy", "Doctor's Office", "Dental Clinic", "Vision Center"],
    "Education": ["University", "Online Course", "Bookstore", "Tutorial Service"]
}

def generate_recurring_transactions(user_id, start_date, num_days):
    """Generate recurring transactions with fixed patterns"""
    recurring_transactions = []
    
  
    current_date = start_date
    while current_date <= start_date + timedelta(days=num_days):
        if current_date.day == 1:  # Monthly on the 1st
            recurring_transactions.append({
                "user_id": user_id,
                "date": current_date,
                "amount": 15.99,
                "merchant": "Netflix",
                "category": "Entertainment",
                "description": "Monthly subscription",
                "is_recurring": True,
                "transaction_type": "debit"
            })
        current_date += timedelta(days=1)
    
  
    current_date = start_date
    while current_date <= start_date + timedelta(days=num_days):
        if current_date.weekday() == 6: 
            recurring_transactions.append({
                "user_id": user_id,
                "date": current_date,
                "amount": 75.00,
                "merchant": "Trader Joe's",
                "category": "Groceries",
                "description": "Weekly grocery shopping",
                "is_recurring": True,
                "transaction_type": "debit"
            })
        current_date += timedelta(days=1)
    
    return recurring_transactions

def generate_unusual_transactions(user_id, start_date, num_days):
    """Generate a few unusual transactions that deviate from normal patterns"""
    unusual_transactions = []
    
    # Add an unusually large grocery purchase
    unusual_date = start_date + timedelta(days=random.randint(1, num_days-1))
    unusual_transactions.append({
        "user_id": user_id,
        "date": unusual_date,
        "amount": 450.00,  
        "merchant": "Costco",
        "category": "Groceries",
        "description": "Bulk purchase and party supplies",
        "is_recurring": False,
        "transaction_type": "debit"
    })
    
    # Add an unusually expensive dining experience
    unusual_date = start_date + timedelta(days=random.randint(1, num_days-1))
    unusual_transactions.append({
        "user_id": user_id,
        "date": unusual_date,
        "amount": 250.00, 
        "merchant": "Local Restaurant",
        "category": "Dining",
        "description": "Anniversary dinner",
        "is_recurring": False,
        "transaction_type": "debit"
    })
    
    return unusual_transactions

def generate_transaction(user_id, date):
    """Generate a regular transaction"""
    category = random.choice(CATEGORIES)
    merchant = random.choice(MERCHANTS[category])
    
    # Generate realistic amounts based on category
    amount_ranges = {
        "Groceries": (20, 100),
        "Dining": (10, 50),
        "Transportation": (5, 30),
        "Entertainment": (10, 50),
        "Shopping": (20, 150),
        "Utilities": (50, 200),
        "Healthcare": (20, 100),
        "Education": (100, 500)
    }
    
    amount = round(random.uniform(*amount_ranges[category]), 2)
    
    return {
        "user_id": user_id,
        "date": date,
        "amount": amount,
        "merchant": merchant,
        "category": category,
        "description": fake.sentence(),
        "is_recurring": False,
        "transaction_type": "debit"
    }

def generate_sample_data(user_id, num_days=90):
    """Generate a mix of regular, recurring, and unusual transactions"""
    transactions = []
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=num_days)
    
    # Generate recurring transactions
    transactions.extend(generate_recurring_transactions(user_id, start_date, num_days))
    
    # Generate unusual transactions
    transactions.extend(generate_unusual_transactions(user_id, start_date, num_days))
    
    # Generate regular transactions
    current_date = start_date
    while current_date <= end_date:
        # Generate 1-3 regular transactions per day
        num_transactions = random.randint(1, 3)
        for _ in range(num_transactions):
            transaction = generate_transaction(user_id, current_date)
            transactions.append(transaction)
        
        current_date += timedelta(days=1)
    
    # Sort all transactions by date
    transactions.sort(key=lambda x: x['date'])
    return transactions