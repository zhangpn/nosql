# Personal Finance Pattern Analyzer

A financial analysis tool built with Flask and MongoDB that helps users track spending, analyze transaction patterns, and manage budgets through a comprehensive REST API.

## Project Overview

The Personal Finance Pattern Analyzer is designed to provide valuable insights into personal financial behavior through:
- Transaction tracking and categorization
- Spending pattern detection
- Budget management and monitoring
- Automated financial analysis
- Recurring payment identification
- Unusual transaction detection

## Tech Stack

- Backend: Flask (Python)
- Database: MongoDB
- Frontend: HTML with Tailwind CSS
- Containerization: Docker

## Setup Instructions

### Prerequisites

- Python 3.8 or higher
- MongoDB
- Docker and Docker Compose 

## Setup Instructions

### Setup Steps

1. Clone the Project:
- Download all the files and get into the project directory
```bash
cd personal-finance-analyzer
```

2. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Start MongoDB using Docker:
```bash
docker compose up
```

5. In a new terminal, set up environment variables:
```bash
export MONGODB_URI="mongodb://localhost:27017/"
export DATABASE_NAME="finance_analyzer"
export SECRET_KEY="your-secret-key"
```

6. Initialize the database with sample data:
```bash
python main.py --init-db --days 90
```

7. Start the Flask application:
```bash
python main.py
```

The application will be available at `http://localhost:5000`

### Note on Database Initialization
- The `docker compose up` command starts an empty MongoDB instance
- `python main.py --init-db` creates a test user and populates the database with sample transaction data
- Sample data includes transactions across various categories (Groceries, Dining, etc.) with realistic amounts
- By default, it generates 90 days of transaction history

### Verifying Setup
1. Access `http://localhost:5000` in your browser
2. Register a new user or use the test account:
   - Email: test@example.com
   - Password: testpassword123
3. You should see sample transactions in the dashboard

### Troubleshooting
- Ensure MongoDB container is running (`docker ps`)
- Check MongoDB connection: 
```bash
docker exec -it <mongodb-container-name> mongosh
use finance_analyzer
db.transactions.find().limit(1)
```
- Verify environment variables are set correctly

## Key Features

### 1. Transaction Management
- Record and categorize financial transactions
- Filter and search transactions by date, category, and merchant
- View transaction history with pagination

### 2. Budget Management
- Set monthly budgets by category
- Track spending against budgets
- Real-time budget compliance monitoring
- Visual budget progress indicators

### 3. Financial Analysis

The system supports various analytical queries including:

#### Pattern Detection
- Monthly/weekly spending by category
- Budget compliance tracking
- Recurring payment identification
- Unusual transaction detection
- Merchant frequency analysis
- Category-wise spending comparison

#### Trend Analysis
- Spending trends over time

## API Endpoints

### Authentication
- `POST /api/register` - Register new user
- `POST /api/login` - User login
- `POST /api/logout` - User logout

### Transactions
- `GET /api/transactions` - List transactions with filtering options
- `POST /api/transactions` - Create new transaction
- `GET /api/transactions/<id>` - Get specific transaction

### Budgets
- `GET /api/budgets` - List all budgets
- `POST /api/budgets` - Create/update budget
- `GET /api/budgets/<category>` - Get specific budget
- `DELETE /api/budgets/<category>` - Delete budget
- `GET /api/budgets/tracking` - Get budget tracking statistics

### Analysis
- `GET /api/analysis/recurring` - Get recurring transaction patterns
- `GET /api/analysis/unusual` - Get unusual transactions
- `GET /api/analysis/trends` - Get spending trends





