from datetime import datetime, timedelta
from collections import defaultdict
import numpy as np
from bson.objectid import ObjectId

class TransactionPatternAnalyzer:
    def __init__(self, db):
        self.db = db

    def detect_recurring_transactions(self, user_id, time_window_days=90):
        """Detect recurring transactions based on merchant and amount patterns"""
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=time_window_days)
        
        pipeline = [
            {"$match": {
                "user_id": ObjectId(user_id),
                "date": {"$gte": start_date, "$lte": end_date}
            }},
            {"$group": {
                "_id": {
                    "merchant": "$merchant",
                    "amount": {"$round": ["$amount", 2]}
                },
                "count": {"$sum": 1},
                "dates": {"$push": "$date"}
            }},
            {"$match": {"count": {"$gte": 2}}}  
        ]
        
        recurring = self.db.transactions.aggregate(pipeline)
        recurring_patterns = []
        
        for pattern in recurring:
            dates = sorted(pattern['dates'])
            intervals = [(dates[i+1] - dates[i]).days for i in range(len(dates)-1)]
            
            if intervals:
                avg_interval = sum(intervals) / len(intervals)
                std_interval = np.std(intervals) if len(intervals) > 1 else 0
                
                # Consider as recurring if standard deviation is less than 5 days
                if std_interval < 5:
                    recurring_patterns.append({
                        "merchant": pattern['_id']['merchant'],
                        "amount": pattern['_id']['amount'],
                        "frequency_days": round(avg_interval),
                        "confidence": 1.0 - (std_interval / 5) if std_interval < 5 else 0
                    })
        
        return recurring_patterns

    def detect_unusual_transactions(self, user_id, lookback_days=90):
        """Detect unusual transactions based on historical patterns"""
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=lookback_days)
        
     
        pipeline = [
            {"$match": {
                "user_id": ObjectId(user_id),
                "date": {"$gte": start_date, "$lte": end_date}
            }},
            {"$group": {
                "_id": "$category",
                "avg_amount": {"$avg": "$amount"},
                "stddev_amount": {"$stdDevPop": "$amount"}
            }}
        ]
        
        category_stats = {
            stat['_id']: {
                'avg': stat['avg_amount'],
                'stddev': stat['stddev_amount']
            }
            for stat in self.db.transactions.aggregate(pipeline)
        }
        
        # Find transactions that deviate significantly from the mean
        unusual_transactions = []
        transactions = self.db.transactions.find({
            "user_id": ObjectId(user_id),
            "date": {"$gte": start_date}
        })
        
        for transaction in transactions:
            category = transaction['category']
            if category in category_stats:
                z_score = abs(
                    (transaction['amount'] - category_stats[category]['avg']) /
                    category_stats[category]['stddev'] if category_stats[category]['stddev'] > 0 else 0
                )
                
                if z_score > 2:  # More than 2 standard deviations from mean
                    transaction['_id'] = str(transaction['_id'])
                    transaction['user_id'] = str(transaction['user_id'])
                    transaction['unusual_score'] = z_score
                    unusual_transactions.append(transaction)
        
        return unusual_transactions

    def analyze_spending_trends(self, user_id, time_window_days=90):
        """Analyze spending trends over time"""
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=time_window_days)
        
        pipeline = [
            {"$match": {
                "user_id": ObjectId(user_id),
                "date": {"$gte": start_date, "$lte": end_date}
            }},
            {"$group": {
                "_id": {
                    "year": {"$year": "$date"},
                    "month": {"$month": "$date"},
                    "category": "$category"
                },
                "total_amount": {"$sum": "$amount"}
            }},
            {"$sort": {"_id.year": 1, "_id.month": 1}}
        ]
        
        monthly_trends = self.db.transactions.aggregate(pipeline)
        
        trends = defaultdict(lambda: defaultdict(dict))
        for trend in monthly_trends:
            year = trend['_id']['year']
            month = trend['_id']['month']
            category = trend['_id']['category']
            trends[f"{year}-{month:02d}"][category] = trend['total_amount']
        
        return dict(trends)