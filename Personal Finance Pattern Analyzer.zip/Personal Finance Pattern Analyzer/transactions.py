from flask import jsonify, request, current_app, session
from app.api import bp
from datetime import datetime
from bson.objectid import ObjectId

def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"error": "Authentication required"}), 401
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

@bp.route('/transactions', methods=['POST'])
@login_required
def create_transaction():
    user_id = session['user_id']
    data = request.get_json()
    
    # Validate required fields
    if not data or not all(k in data for k in ['amount', 'merchant', 'category']):
        return jsonify({"error": "Missing required fields"}), 400
    
    # Create transaction document
    transaction = {
        "user_id": ObjectId(user_id),
        "date": datetime.utcnow(),
        "amount": float(data['amount']),
        "merchant": data['merchant'],
        "category": data['category'],
        "description": data.get('description', ''),
        "is_recurring": False,  # Will be updated by pattern detection
        "transaction_type": data.get('transaction_type', 'debit')
    }
    
    try:
        # Insert transaction
        result = current_app.db.transactions.insert_one(transaction)
        
        return jsonify({
            "message": "Transaction created",
            "id": str(result.inserted_id),
            "amount": transaction['amount'],
            "merchant": transaction['merchant'],
            "category": transaction['category']
        }), 201
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@bp.route('/transactions', methods=['GET'])
@login_required
def get_transactions():
    user_id = session['user_id']
    
    try:
        # Parse query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        category = request.args.get('category')
        merchant = request.args.get('merchant')
        
        # Build query
        query = {"user_id": ObjectId(user_id)}
        
        if start_date:
            query["date"] = {"$gte": datetime.fromisoformat(start_date)}
        if end_date:
            query["date"] = query.get("date", {}) | {"$lte": datetime.fromisoformat(end_date)}
        if category:
            query["category"] = category
        if merchant:
            query["merchant"] = merchant
            
        # Handle pagination
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
        skip = (page - 1) * per_page
        
        # Execute query
        total_count = current_app.db.transactions.count_documents(query)
        transactions = list(
            current_app.db.transactions
            .find(query)
            .sort("date", -1)
            .skip(skip)
            .limit(per_page)
        )
        
        # Prepare response
        for transaction in transactions:
            transaction['_id'] = str(transaction['_id'])
            transaction['user_id'] = str(transaction['user_id'])
            transaction['date'] = transaction['date'].isoformat()
            
        return jsonify({
            "transactions": transactions,
            "page": page,
            "per_page": per_page,
            "total_count": total_count,
            "total_pages": (total_count + per_page - 1) // per_page
        }), 200
        
    except ValueError as e:
        return jsonify({"error": "Invalid date format"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@bp.route('/transactions/<transaction_id>', methods=['GET'])
@login_required
def get_transaction(transaction_id):
    user_id = session['user_id']
    
    try:
        transaction = current_app.db.transactions.find_one({
            "_id": ObjectId(transaction_id),
            "user_id": ObjectId(user_id)
        })
        
        if not transaction:
            return jsonify({"error": "Transaction not found"}), 404
            
        transaction['_id'] = str(transaction['_id'])
        transaction['user_id'] = str(transaction['user_id'])
        transaction['date'] = transaction['date'].isoformat()
        
        return jsonify(transaction), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400