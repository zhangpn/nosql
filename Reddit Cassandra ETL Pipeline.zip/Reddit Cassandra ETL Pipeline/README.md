
# Nosql Project - README

## Project Summary
This project enables users to scrape, clean, and analyze Reddit data using a structured workflow. It leverages Python scripts for data extraction, transformation, and querying using Cassandra. The main functionalities include scraping posts and comments from a subreddit, cleaning and converting data into a format suitable for database insertion, and querying the data for insights like top posts, active users, and high engagement content.

## Setup Instructions

### Prerequisites
- **Python 3.8 or higher**
- **Cassandra 4.0 or higher**
- **Docker and Docker Compose** (for deploying Cassandra easily)
- Python libraries: `praw`, `datetime`, `json`, `time`, `cassandra-driver`, and others mentioned in `requirements.txt`.

### 1. Clone the Repository
```bash
git clone <repository-url>
cd <repository-folder>
```

### 2. Install Python Dependencies
Set up a virtual environment and install dependencies:
```bash
python3 -m venv env
source env/bin/activate  # On Windows: env\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure Docker
Start the Cassandra instance using Docker Compose:
```bash
docker-compose up
```

### 4. Configure Cassandra
Open the Cassandra shell:
```bash
docker exec -it cassandra cqlsh
```
Create the keyspace and tables. Example schema:
```cql
CREATE KEYSPACE reddit_data WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 1};
USE reddit_data;
CREATE TABLE posts_data (
    post_id TEXT PRIMARY KEY,
    title TEXT,
    content TEXT,
    date TIMESTAMP,
    author TEXT,
    upvotes INT,
    subreddit TEXT
);

CREATE TABLE comments_data (
    comment_id TEXT PRIMARY KEY,
    post_id TEXT,
    comment TEXT,
    date TIMESTAMP,
    author TEXT,
    upvotes INT
);
```

### 5. Configure Reddit API
Update the `Subreddits_Scraping.py` file with your Reddit API credentials:
```python
reddit = praw.Reddit(client_id='your_client_id', 
                     client_secret='your_client_secret', 
                     user_agent='your_user_agent')
```

### 6. Run the Workflow
1. **Scrape Subreddit Data**:
   ```bash
   python Subreddits_Scraping.py
   ```
   This script retrieves posts and comments and stores them in `comments_data.json`.

2. **Clean and Prepare Data**:
   ```bash
   python Data_Cleaning.py
   ```
   This script processes the scrapped reddit data to json and csv format for posts and comments that are suitable for insertion.
3. **Import CSV Data Into Cassandra**:
   Manually copy csv file into docker container then use COPY in cql:
   ```bash
   docker cp comments.csv cassandra:/comments.csv
   docker cp posts.csv cassandra:/posts.csv 
   ```
   ```cql
   COPY posts_data (post_id, title, content, date, author, upvotes, subreddit)
   FROM '/posts.csv' WITH HEADER = TRUE;
   COPY comments_data (comment_id, comment, date, author, upvotes, post_id)
   FROM '/comments.csv' WITH HEADER = TRUE;
   ```

   Or run the Data_Import.py to insert json file line by line:
   ```bash
   python Data_Import.py
   ```
   This script import the scrapped data into Cassandra.
5. **Query the Data**:
   Run various queries defined in `app.py`.
   Examples:
   ```bash
   python app.py recent       # Get recent posts from the last 7 days
   python app.py top 5        # Retrieve top 5 posts by upvotes
   python app.py active       # Get the most active users
   ```

## Replication
1. Use the Docker Compose file to ensure a consistent Cassandra environment.
2. Populate the database using the provided scripts (`Subreddits_Scraping.py` and `Data_Cleaning.py`).
3. Execute queries in `app.py` to verify functionality.

For questions or further assistance, refer to the comments within each script or contact the project maintainer.
