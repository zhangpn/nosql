import sys
from datetime import datetime, timedelta
from cassandra.cluster import Cluster

# Connect to Cassandra
cluster = Cluster(['127.0.0.1'])  # Update with your Cassandra IP or hostname
session = cluster.connect()
session.set_keyspace('reddit_data')  # Replace with your keyspace name


# Query 1: Get posts by a specific user
def get_posts_by_user(author_name):
    rows = session.execute("SELECT * FROM posts_by_author WHERE author = %s", (author_name,))
    for row in rows:
        print(f"Post ID: {row.post_id}, Title: {row.title}, Date: {row.date}, Upvotes: {row.upvotes}")

# Query 2: Get recent posts from the last 7 days
def get_recent_posts():
    last_7_days = datetime.now() - timedelta(days=7)
    rows = session.execute("SELECT * FROM posts_data WHERE date > %s ALLOW FILTERING", (last_7_days,))
    for row in rows:
        print(f"Post ID: {row.post_id}, Title: {row.title}, Date: {row.date}")


# Query 3: Find posts title containing specific keywords
def find_posts_with_keyword(keyword):
    rows = session.execute("SELECT * FROM posts_data")
    for row in rows:
        if keyword.lower() in row.title.lower():
            print(f"Post ID: {row.post_id}, Title: {row.title}")


# Query 4: Count comments on a specific post
def count_comments(post_id):
    rows = session.execute("SELECT COUNT(*) FROM comments_by_posts WHERE post_id = %s", (post_id,))
    count = rows.one()
    if count:
        print(f"Number of comments for post {post_id}: {count[0]}")
    else:
        print(f"No comments found for post {post_id}")


# Query 5: Retrieve top posts by upvotes
def get_top_posts(limit=5):
    rows = session.execute("SELECT * FROM posts_data")
    sorted_posts = sorted(rows, key=lambda x: x.upvotes, reverse=True)[:limit]
    for post in sorted_posts:
        print(f"Post ID: {post.post_id}, Title: {post.title}, Upvotes: {post.upvotes}")

# Query 6: Get posts with high engagement
def get_high_engagement_posts(comment_threshold=10, upvote_threshold=100):
    # Fetch all posts
    posts = session.execute("SELECT post_id, title, upvotes FROM posts_data")
    
    high_engagement_posts = []

    for post in posts:
        comment_count_result = session.execute("SELECT COUNT(*) FROM comments_by_posts WHERE post_id = %s", (post.post_id,))
        comment_count = comment_count_result.one()[0] if comment_count_result else 0

        if comment_count >= comment_threshold and post.upvotes >= upvote_threshold:
            high_engagement_posts.append({
                'post_id': post.post_id,
                'title': post.title,
                'comments': comment_count,
                'upvotes': post.upvotes
            })

    # Print results
    if high_engagement_posts:
        print("High Engagement Posts:")
        for post in high_engagement_posts:
            print(f"Post ID: {post['post_id']}, Title: {post['title']}, Comments: {post['comments']}, Upvotes: {post['upvotes']}")
    else:
        print("No high engagement posts found.")



# Query 7: Retrieve the most active users
def get_most_active_users():
    from collections import Counter

    post_counts = Counter()
    rows = session.execute("SELECT author FROM posts_data")
    for row in rows:
        post_counts[row.author] += 1

    comment_counts = Counter()
    rows = session.execute("SELECT author FROM comments_data")
    for row in rows:
        comment_counts[row.author] += 1

    combined_counts = post_counts + comment_counts
    for user, count in combined_counts.most_common(5):
        print(f"User: {user}, Activity: {count}")


# Command-line interface
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 run_app.py <command> [arguments]")
        print("Commands:")
        print("  user <author_name>                - Get posts by a specific user")
        print("  recent                            - Get recent posts from the last 7 days")
        print("  keyword <keyword>                 - Find posts containing a specific keyword")
        print("  count <post_id>                   - Count comments on a specific post")
        print("  top <limit>                       - Get top posts by upvotes")
        print("  high <comment_threshold> <upvote_threshold> - Get posts with high engagement")
        print("  active                            - Get the most active users")
        sys.exit(1)

    command = sys.argv[1]

    try:
        if command == "user":
            if len(sys.argv) != 3:
                print("Usage: python run_app.py user <author_name>")
            else:
                get_posts_by_user(sys.argv[2])

        elif command == "recent":
            get_recent_posts()

        elif command == "keyword":
            if len(sys.argv) != 3:
                print("Usage: python run_app.py keyword <keyword>")
            else:
                find_posts_with_keyword(sys.argv[2])

        elif command == "count":
            if len(sys.argv) != 3:
                print("Usage: python run_app.py count <post_id>")
            else:
                count_comments(sys.argv[2])

        elif command == "top":
            if len(sys.argv) != 3:
                print("Usage: python run_app.py top <limit>")
            else:
                get_top_posts(int(sys.argv[2]))

        elif command == "high":
            if len(sys.argv) != 4:
                print("Usage: python run_app.py high <comment_threshold> <upvote_threshold>")
            else:
                get_high_engagement_posts(int(sys.argv[2]), int(sys.argv[3]))

        elif command == "active":
            get_most_active_users()

        else:
            print("Unknown command. Use 'user', 'recent', 'keyword', 'count', 'top', 'high', or 'active'.")
    except Exception as e:
        print(f"Error: {e}")
