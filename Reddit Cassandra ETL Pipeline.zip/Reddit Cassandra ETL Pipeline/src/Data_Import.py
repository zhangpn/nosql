import json
from cassandra.cluster import Cluster

# Connect to Cassandra
cluster = Cluster(['127.0.0.1'])
session = cluster.connect()
session.set_keyspace('reddit_data')

# Load JSON data
with open('../data/posts.json', 'r', encoding='utf-8') as file:
    data = json.load(file)

i = 1
for post in data:
    print(f'Inserting Post {i}:')
    i += 1
    session.execute("""
        INSERT INTO posts_data (post_id, title, content, date, author, upvotes, subreddit)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, (post['post_id'], post['title'], post['content'], post['date'], post['author'], post['upvotes'], post['subreddit']))

with open('../data/comments.json', 'r', encoding='utf-8') as file:
    data = json.load(file)
    
i = 1
for comment in data:
    print(f'Inserting Comment {i}:')
    i += 1
    session.execute("""
        INSERT INTO comments_data (comment_id, comment, date, author, upvotes, post_id)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (comment['comment_id'], comment['comment'], comment['date'], comment['author'], comment['upvotes'],comment['post_id']))

# Migrate Data for posts_by_author
rows = session.execute("SELECT * FROM posts_data")
for row in rows:
    session.execute("""
        INSERT INTO posts_by_author (author, post_id, date, title, content, upvotes, subreddit)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, (row.author, row.post_id, row.date, row.title, row.content, row.upvotes, row.subreddit))
print("Data migration to posts_by_author completed.")

# Migrate Data for comments_by_post
rows = session.execute("SELECT * FROM comments_data")
for row in rows:
    session.execute("""
        INSERT INTO comments_by_posts (post_id, comment_id, date, author, comment, upvotes)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (row.post_id, row.comment_id, row.date, row.author, row.comment, row.upvotes))
print("Data migration to comments_by_posts completed.")

