import praw
import datetime as dt
import json
import time


# Reddit credentials
reddit = praw.Reddit(client_id='kIl2JAx3TtA6cta50C_i4Q', 
                     client_secret='usRm7irdycBOLKi7SyARg6mUFQ8RCw', 
                     user_agent='Stelram')

subreddit_name = "Genshin_Impact"
subreddit = reddit.subreddit(subreddit_name)

file_path = '../data/comments_data.json'

def save_to_file(data, file_path): 
    with open(file_path, 'a', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
        f.write('\n')

def process_comment(comment):
    comment_data = {
        "id": comment.id,
        "post_id": submission.id,
        "author": str(comment.author),
        "comment": comment.body,
        "date":  dt.datetime.fromtimestamp(comment.created_utc).isoformat(),
        "upvotes": comment.score,
        "replies": [process_comment(reply) for reply in comment.replies]
    }
    return comment_data

with open(file_path, 'w') as file:
    file.write("")
for submission in subreddit.hot(limit=None):
    submission.comments.replace_more(limit=None)
    comments_data = [process_comment(comment) for comment in submission.comments.list()]

    post_data = {
        "id": submission.id,
        "author": str(submission.author),
        "title": submission.title,
        "content": submission.selftext,
        "date": dt.datetime.fromtimestamp(submission.created_utc).isoformat(),
        "upvotes": submission.score,
        "comments": comments_data,
        "Subreddit": subreddit_name
    }

    save_to_file(post_data,file_path)
    time.sleep(2)