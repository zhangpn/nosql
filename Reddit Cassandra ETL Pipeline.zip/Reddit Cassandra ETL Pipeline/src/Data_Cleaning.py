import json
from datetime import datetime
import re
import pandas as pd

# Data should be unix format to be imported into cassandra
def to_unix_timestamp(date_value):
    if isinstance(date_value, pd.Timestamp):
        date_str = date_value.strftime("%Y-%m-%d %H:%M:%S")
    else:
        date_str = str(date_value)

    try:
        # First attempt: Format with space
        dt = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        # Fallback to format with 'T'
        dt = datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S")

    return int(dt.timestamp()*1000)

# Clean emojis 
def clean_text(text):
    if isinstance(text, str):
        pattern = r"[^A-Za-z0-9 .,!?'\-\"@#&$%*(){}[\]:;/\n±§°^~<>|+=_–‘’“”…`]"
        return re.sub(pattern, "", text)
    return text

# Collect all comments in a post
def collect_comments(data, all_comments):
    # Recursively collect comments and their replies, adding post_id for each comment.
    for comment_dict in data:
        all_comments.append({
            "comment_id": comment_dict["id"],
            "comment": comment_dict["comment"],
            "date": str(comment_dict["date"]),
            "author": comment_dict["author"],
            "upvotes": comment_dict["upvotes"],
            "post_id": current_post_id,
        })

        if len(comment_dict.get("replies", [])) > 0:
            collect_comments(comment_dict["replies"], all_comments)

file_path = "../data/comments_data.json"
modified_file_path = "../data/modified_comments_data.json"
posts_output = "../data/posts.json"
comments_output = "../data/comments.json"

with open(modified_file_path, "w") as file:
    file.write("")

with open(file_path, "r", encoding="utf-8") as file:
    content = file.read().strip()

# Modify content by adding square brackets and commas to make it a valid JSON array
modified_content = "[" + content.replace("}\n{", "},{") + "]"

with open(modified_file_path, "w", encoding="utf-8") as modified_file:
    modified_file.write(modified_content)

posts = []
comments = []

with open(modified_file_path, "r", encoding="utf-8") as file:
    data = pd.read_json(file)
    for index, post in data.iterrows():
        # Process posts
        posts.append({
            "post_id": post["id"],
            "title": post["title"],
            "content": post["content"],
            "date": str(post["date"]),
            "author": post["author"],
            "upvotes": post["upvotes"],
            "subreddit": post["Subreddit"]
        })

        # Process comments linked to the post
        current_post_id = post["id"]  # Set current post ID for comments
        collect_comments(post["comments"], comments)

# Apply unix time to data and clean strings
for post in posts:
    post["date"] = to_unix_timestamp(post["date"])
    for key, value in post.items():
        if isinstance(value, str):
            post[key] = clean_text(value)

for comment in comments:
    comment["date"] = to_unix_timestamp(comment["date"])
    for key, value in comment.items():
        if isinstance(value, str):
            comment[key] = clean_text(value)
    

# Load data
with open(posts_output, "w", encoding="utf-8") as f:
    json.dump(posts, f, ensure_ascii=False, indent=4)

with open(comments_output, "w", encoding="utf-8") as f:
    json.dump(comments, f, ensure_ascii=False, indent=4)

# Fill in empty strings and na values when converting to csv for insert
def json_to_csv(json_file, csv_file):
    df = pd.read_json(json_file)
    df = df.replace("", "Not Provided")
    df = df.fillna("Not Provided")
    df.to_csv(csv_file, index=False, encoding='utf-8')

json_to_csv("../data/posts.json", "../data/posts.csv")
json_to_csv("../data/comments.json", "../data/comments.csv")