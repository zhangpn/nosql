from pymongo import MongoClient
import redis
import json
import threading
from datetime import datetime

# Chatbot class for TreeHouse Family application
class FamilyChatbot:
    def __init__(self, host='redis', port=6379): # use "host = 'redis'" for Macbook and "host = 'localhost'" for Windows.
        """
        Initialize Redis connection and set up TreeHouse Family channels.
        :param host: Redis host address (default is 'redis').
        :param port: Redis port (default is 6379).
        """
        # Connect to Redis
        self.client = redis.StrictRedis(host=host, port=port, decode_responses=True)
        self.pubsub = self.client.pubsub()  # Initialize Pub/Sub system
        self.username = None  # Placeholder for user's identity

        # Predefined chat channels for the family
        self.available_channels = ["family_forum", "birthdays", "generations", "family_reunion"]
        print(f"🌳 Available Channels: {', '.join(self.available_channels)}")

    def introduce(self):
        """
        Display an introduction message and available commands for the chatbot.
        """
        intro = """
        ╔═══════════════════════════════════════════╗
        ║  Welcome to TreeHouse Family Chatbot! 🌳  ║
        ╚═══════════════════════════════════════════╝
        Available commands:
        1. !help: Show this help message
        2. !identify: Introduce yourself to the chatbot
        3. !whoami: Show your stored user information
        4. !join <channel1,channel2,...>: Join one or more channels
        5. !leave <channel1,channel2,...>: Leave one or more channels
        6. !message <channel1,channel2,...> <message>: Send a message to one or more channels
        7. !listen: Start listening to messages in subscribed channels
        8. !addmilestone <name> <type> <date>: Add a milestone (format: YYYY-MM-DD)
        9. !search <name>: Search for a family member
        10. !members <channel>: List all users in a channel
        11. !dm <username> <message>: Send a direct message to a user
        """
        print(intro)

    def identify(self):
        """
        Allow the user to identify themselves and store their information in Redis.
        """
        print("👋 Let's get to know you!")
        username = input("📝 Enter your username: ").strip()
        age = input(f"👶 How old are you, {username}? ").strip()
        relation = input("💞 Your relation to the family (e.g., Parent, Child): ").strip()
        location = input(f"📍 Where are you from, {username}? ").strip()

        # Save the user's information in Redis
        user_info = {'username': username, 'age': age, 'relation': relation, 'location': location}
        self.client.set(f"user:{username.lower()}", json.dumps(user_info))
        self.username = username
        print(f"✔ Info stored, {username}! You're all set! 🌟")

    def add_milestone(self, name, milestone_type, milestone_date):
        """
        Add a milestone for a family member and store it in Redis.
        :param name: Name of the family member.
        :param milestone_type: Type of milestone (e.g., 'Birthday', 'Anniversary').
        :param milestone_date: Date of the milestone in 'YYYY-MM-DD' format.
        """
        try:
            # Validate and format the date
            milestone_date = datetime.strptime(milestone_date, "%Y-%m-%d").strftime("%Y-%m-%d")
            milestone = {"type": milestone_type, "date": milestone_date}

            # Retrieve existing milestones from Redis or create a new list
            existing_milestones = self.client.get(f"milestones:{name.lower()}")
            milestones = json.loads(existing_milestones) if existing_milestones else []

            # Add the new milestone and save it back to Redis
            milestones.append(milestone)
            self.client.set(f"milestones:{name.lower()}", json.dumps(milestones))
            print(f"✔ Milestone added for {name}: {milestone_type} on {milestone_date}")
        except ValueError:
            print("⚠ Invalid date format. Use YYYY-MM-DD.")

    def join_channels(self, channels):
        """
        Subscribe to one or more channels.
        :param channels: Comma-separated string of channel names.
        """
        channels = [channel.strip() for channel in channels.split(",")]
        for channel in channels:
            if channel not in self.available_channels:
                print(f"⚠ Channel '{channel}' is not available. Choose from: {', '.join(self.available_channels)}")
            else:
                self.pubsub.subscribe(channel)
                print(f"✔ Joined channel: {channel.upper()} 🎙️")

    def leave_channels(self, channels):
        """
        Unsubscribe from one or more channels.
        :param channels: Comma-separated string of channel names.
        """
        channels = [channel.strip() for channel in channels.split(",")]
        for channel in channels:
            if channel not in self.available_channels:
                print(f"⚠ Channel '{channel}' is not available.")
            else:
                self.pubsub.unsubscribe(channel)
                print(f"✔ Left channel: {channel.upper()} 🚪")

    def send_message_to_channels(self, channels, message):
        """
        Publish a message to one or more channels.
        :param channels: Comma-separated string of channel names.
        :param message: Message text to send.
        """
        channels = [channel.strip() for channel in channels.split(",")]
        for channel in channels:
            if channel not in self.available_channels:
                print(f"⚠ Channel '{channel}' is not available. Join the channel first.")
            else:
                self.client.publish(channel, f"{self.username}: {message}")
                print(f"📢 Message sent to {channel.upper()}: {message}")

    def read_messages(self):
        """
        Listen to and display messages from subscribed channels.
        """
        print("👂 Listening for messages from subscribed channels...")
        for message in self.pubsub.listen():
            if message['type'] == 'message':
                print(f"🔔 [{message['channel'].upper()}] {message['data']}")

    def search_member(self, name):
        """
        Search for a family member's information in Redis.
        :param name: Name of the family member.
        """
        member_data = self.client.get(f"user:{name.lower()}")
        if member_data:
            member_info = json.loads(member_data)
            print(f"📝 Found Member: {name}")
            for key, value in member_info.items():
                print(f"   {key.capitalize()}: {value}")
        else:
            print(f"⚠ No data found for member: {name}.")

    def list_members_in_channel(self, channel):
        """
        Simulate listing members in a channel (Pub/Sub does not track subscribers).
        :param channel: Channel name.
        """
        if channel not in self.available_channels:
            print(f"⚠ Channel '{channel}' is not available.")
            return
        print(f"👥 Members in {channel.upper()}:\n - Sai\n - Alice\n - Bob (Demo Members)")

    def send_direct_message(self, username, message):
        """
        Simulate sending a direct message to another user.
        :param username: Recipient username.
        :param message: Message text.
        """
        user_data = self.client.get(f"user:{username.lower()}")
        if user_data:
            print(f"✉️ Direct message sent to {username}: {message}")
        else:
            print(f"⚠ User '{username}' not found.")

    def process_commands(self, message):
        """
        Process user commands and execute the corresponding methods.
        :param message: Command input by the user.
        """
        if message.startswith('!help'):
            self.introduce()
        elif message.startswith('!identify'):
            self.identify()
        elif message.startswith('!whoami'):
            if self.username:
                user_data = self.client.get(f"user:{self.username.lower()}")
                if user_data:
                    user_info = json.loads(user_data)
                    print(f"👤 {self.username}'s Info:\n{user_info}")
                else:
                    print("⚠ No information stored for you. Use !identify to set up.")
            else:
                print("⚠ You haven't identified yourself yet. Use !identify to introduce yourself.")
        elif message.startswith('!join'):
            try:
                _, channels = message.split(maxsplit=1)
                self.join_channels(channels)
            except ValueError:
                print("⚠ Format: !join <channel1,channel2,...>")
        elif message.startswith('!leave'):
            try:
                _, channels = message.split(maxsplit=1)
                self.leave_channels(channels)
            except ValueError:
                print("⚠ Format: !leave <channel1,channel2,...>")
        elif message.startswith('!message'):
            try:
                _, channels_and_message = message.split(maxsplit=1)
                channels, message = channels_and_message.split(maxsplit=1)
                self.send_message_to_channels(channels, message)
            except ValueError:
                print("⚠ Format: !message <channel1,channel2,...> <message>")
        elif message.startswith('!addmilestone'):
            try:
                _, name, milestone_type, milestone_date = message.split(maxsplit=3)
                self.add_milestone(name, milestone_type, milestone_date)
            except ValueError:
                print("⚠ Format: !addmilestone <name> <type> <date> (e.g., !addmilestone Alice Birthday 2023-12-25)")
        elif message.startswith('!listen'):
            threading.Thread(target=self.read_messages, daemon=True).start()
        elif message.startswith('!search'):
            try:
                _, name = message.split(maxsplit=1)
                self.search_member(name)
            except ValueError:
                print("⚠ Format: !search <name>")
        elif message.startswith('!members'):
            try:
                _, channel = message.split(maxsplit=1)
                self.list_members_in_channel(channel)
            except ValueError:
                print("⚠ Format: !members <channel>")
        elif message.startswith('!dm'):
            try:
                _, username, *msg = message.split()
                message_text = " ".join(msg)
                self.send_direct_message(username, message_text)
            except ValueError:
                print("⚠ Format: !dm <username> <message>")
        else:
            print("⚠ Command not recognized. Use !help to see the list of available commands.")

# Main execution block
if __name__ == "__main__":
    bot = FamilyChatbot()
    bot.introduce()

    # Main command loop for user interaction
    while True:
        user_input = input("You: ").strip()
        bot.process_commands(user_input)
