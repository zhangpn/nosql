from pymongo import MongoClient
import random
from datetime import datetime, timedelta
import json

# MongoDB Connection
# Establish connection to the MongoDB instance and access the 'treehouse' database and 'family_members' collection.
mongo_client = MongoClient("mongodb://mongodb:27017/")
mongo_db = mongo_client["treehouse"]
family_collection = mongo_db["family_members"]

# Helper functions
# Function to generate a random date between two given dates.
def random_date(start, end):
    """
    Generate a random date between the start and end dates.
    :param start: Start date as a datetime object.
    :param end: End date as a datetime object.
    :return: Random date as a string in 'YYYY-MM-DD' format.
    """
    return (start + timedelta(days=random.randint(0, (end - start).days))).strftime('%Y-%m-%d')

# Function to generate realistic family relationships.
def generate_relationships(member_ids, family_data, family_id):
    """
    Generate realistic relationships for family members within the same family.
    Relationships include parent-child, sibling, and spouse.
    :param member_ids: List of member IDs in the family.
    :param family_data: List of all family data.
    :param family_id: Current family ID.
    :return: List of generated relationships for a family member.
    """
    relationships = []
    # Identify parents (born before 1990) and children (born in or after 1990).
    parent_candidates = [m for m in family_data if m["family_id"] == family_id and datetime.strptime(m["birth_date"], '%Y-%m-%d').year < 1990]
    children_candidates = [m for m in family_data if m["family_id"] == family_id and datetime.strptime(m["birth_date"], '%Y-%m-%d').year >= 1990]

    # Create a parent-child relationship if possible.
    if len(parent_candidates) > 0 and len(children_candidates) > 0:
        parent = random.choice(parent_candidates)
        child = random.choice(children_candidates)
        relationships.append({"type": "parent", "related_to": child["_id"]})
        child["relationships"].append({"type": "child", "related_to": parent["_id"]})

    # Create a sibling relationship if there are at least two children.
    if len(children_candidates) > 1:
        siblings = random.sample(children_candidates, 2)
        relationships.append({"type": "sibling", "related_to": siblings[1]["_id"]})
        siblings[1]["relationships"].append({"type": "sibling", "related_to": siblings[0]["_id"]})

    # Create a spouse relationship if there are at least two parents.
    if len(parent_candidates) > 1:
        spouses = random.sample(parent_candidates, 2)
        relationships.append({"type": "spouse", "related_to": spouses[1]["_id"]})
        spouses[1]["relationships"].append({"type": "spouse", "related_to": spouses[0]["_id"]})

    return relationships

# Function to add important milestones to a family member's profile.
def add_milestones(member):
    """
    Add milestones such as Birthday, Graduation, Wedding Anniversary, and Death based on the member's birth year.
    :param member: Family member dictionary.
    :return: List of milestones.
    """
    birth_year = datetime.strptime(member["birth_date"], '%Y-%m-%d').year
    milestones = [{"type": "Birthday", "date": member["birth_date"]}]
    
    # Add graduation milestone if applicable.
    if birth_year + 22 < datetime.now().year:
        graduation_date = random_date(datetime(birth_year + 22, 1, 1), datetime(birth_year + 22, 12, 31))
        milestones.append({"type": "Graduation", "date": graduation_date})

    # Add marriage milestone if applicable.
    if random.random() > 0.5 and birth_year + 25 < datetime.now().year:
        marriage_date = random_date(datetime(birth_year + 25, 1, 1), datetime(birth_year + 35, 12, 31))
        milestones.append({"type": "Wedding Anniversary", "date": marriage_date})

    # Add death milestone if applicable.
    if random.random() > 0.8 and birth_year + 70 < datetime.now().year:
        death_date = random_date(datetime(birth_year + 70, 1, 1), datetime.now())
        milestones.append({"type": "Death", "date": death_date})

    return milestones

# Generate synthetic family data.
family_data = []
names = [  # First names.
    "John", "Mary", "Robert", "Anna", "James", "Emily", "Michael", "Sophia", "William", "Isabella",
    "Oliver", "Amelia", "Noah", "Mia", "Lucas", "Charlotte", "Liam", "Evelyn", "Elijah", "Abigail"
]
last_names = [  # Last names.
    "Smith", "Johnson", "Brown", "Davis", "Wilson", "Taylor", "Anderson", "Thomas", "Moore", "Jackson"
]
occupations = [  # Occupations for family members.
    "Teacher", "Engineer", "Artist", "Doctor", "Writer", "Chef", "Designer", "Nurse", "Farmer", "Software Developer"
]
colors = [  # Favorite colors.
    "Red", "Blue", "Green", "Yellow", "Purple", "Orange", "Pink", "Black", "White", "Gray"
]
interests = [  # List of interests.
    "Gardening", "Fishing", "Reading", "Traveling", "Cooking", "Hiking", "Gaming", "Pets", "Cycling", "Photography"
]

start_date = datetime(1950, 1, 1)
end_date = datetime(2010, 12, 31)

# Configuration: number of families and members per family.
family_count = 5
members_per_family = 15

# Generate family members and their relationships.
for family_id in range(1, family_count + 1):
    family_member_ids = []
    family_last_name = random.choice(last_names)  # Common last name for family members.
    for i in range(members_per_family):
        member_id = f"Family{family_id}_Member{i+1:03d}"  # Unique ID for each member.
        name = random.choice(names)
        last_name = family_last_name if random.random() > 0.3 else random.choice(last_names)
        full_name = f"{name} {last_name}"
        birth_date = random_date(start_date, end_date)
        gender = random.choice(["Male", "Female", "Non-binary"])
        occupation = random.choice(occupations)
        favorite_color = random.choice(colors)
        has_pet = random.random() > 0.7  # Randomly assign pet ownership.
        interests_list = random.sample(interests, k=random.randint(1, 3))
        family_member_ids.append(member_id)
        member = {
            "_id": member_id,
            "name": full_name,
            "birth_date": birth_date,
            "gender": gender,
            "milestones": [],
            "relationships": [],
            "interests": interests_list,
            "occupation": occupation,
            "favorite_color": favorite_color,
            "has_pet": has_pet,
            "family_id": f"Family{family_id}"
        }
        member["milestones"] = add_milestones(member)
        family_data.append(member)

    # Add relationships for family members.
    for member in family_data[-members_per_family:]:
        member["relationships"].extend(generate_relationships(family_member_ids, family_data, f"Family{family_id}"))

# Insert generated family data into MongoDB.
def insert_data():
    """
    Insert generated family data into the MongoDB 'family_members' collection.
    """
    try:
        family_collection.delete_many({})  # Clear existing data.
        family_collection.insert_many(family_data)
        print(f"{len(family_data)} family members inserted successfully!")
    except Exception as e:
        print(f"Error inserting data: {e}")

# Main execution: insert data and save to JSON.
if __name__ == "__main__":
    insert_data()

# Save the generated data to a JSON file for backup or reuse.
with open("family_members.json", "w") as file:
    json.dump(family_data, file, indent=4)
print("Data saved to family_members.json")
