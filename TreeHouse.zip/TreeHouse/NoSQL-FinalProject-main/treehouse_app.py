import streamlit as st
from pymongo import MongoClient
from neo4j import GraphDatabase
from ics import Calendar, Event
from datetime import datetime
import pandas as pd
import networkx as nx
from pyvis.network import Network
import redis
import threading

# Streamlit page configuration
st.set_page_config(page_title="TreeHouse App", layout="wide")

with st.spinner("Connecting to MongoDB..."):
    # MongoDB Connection
    try:
        # Connect to MongoDB with a 5-second connection timeout
        mongo_client = MongoClient("mongodb://mongodb:27017/", serverSelectionTimeoutMS=5000)
        mongo_db = mongo_client["treehouse"]

        # Attempt to access the family_members collection
        if "family_members" in mongo_db.list_collection_names():
            family_collection = mongo_db["family_members"]
            st.sidebar.success("✅ Connected to MongoDB and found 'family_members' collection")
        else:
            raise ValueError("The 'family_members' collection does not exist in the 'treehouse' database.")
    except Exception as e:
        st.sidebar.error(f"❌ MongoDB connection failed: {e}")
        family_collection = None  # Set to None if connection fails

# Neo4j Connection
class Neo4jConnection:
    def __init__(self, uri, user, password):
        # Establish connection to Neo4j
        self._driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        # Close Neo4j connection
        self._driver.close()

    def query(self, query, parameters=None):
        # Execute a query in Neo4j
        with self._driver.session() as session:
            result = session.run(query, parameters)
            return [record.data() for record in result]

with st.spinner("Connecting to Neo4j..."):
    # Neo4j Connection
    try:
        neo4j_conn = Neo4jConnection(uri="bolt://neo4j:7687", user="neo4j", password="password")
        st.sidebar.success("✅ Connected to Neo4j")
    except Exception as e:
        neo4j_conn = None
        st.sidebar.error(f"❌ Neo4j connection failed: {e}")

with st.spinner("Connecting to Redis..."):
    # Redis Connection
    try:
        redis_client = redis.StrictRedis(host="redis", port=6379, decode_responses=True)
        pubsub = redis_client.pubsub()
        st.sidebar.success("✅ Connected to Redis")
    except Exception as e:
        redis_client = None
        pubsub = None
        st.sidebar.error(f"❌ Redis connection failed: {e}")

# Streamlit App
st.title("TreeHouse Family Tree Application")

# Tabs for MongoDB, Neo4j, and Redis
tab1, tab2, tab3 = st.tabs(["Family Profiles (MongoDB)", "Family Relationships (Neo4j)", "Family Forum (Redis)"])

# Tab 1: MongoDB Queries
with tab1:
    st.header("Family Profiles")

    if family_collection is not None:
        # Search Family Member Profile
        name = st.text_input("Enter Family Member's Name (e.g., Isabella King)", key="name_input")
        if st.button("Search Profile", key="search_profile"):
            try:
                person = family_collection.find_one({"name": name})
                if person:
                    st.markdown(f"### Profile of {person['name']}")
                    st.markdown(f"**ID:** {person['_id']}")
                    st.markdown(f"**Name:** {person['name']}")
                    st.markdown(f"**Birthday:** {datetime.strptime(person['birth_date'], '%Y-%m-%d').strftime('%B %d, %Y')}")
                    st.markdown(f"**Gender:** {person['gender']}")
                    st.markdown(f"**Favorite Color:** {person.get('favorite_color', 'N/A')}")
                    st.markdown(f"**Occupation:** {person.get('occupation', 'N/A')}")
                    st.markdown(f"**Has Pet:** {'Yes' if person.get('has_pet', False) else 'No'}")
                    st.markdown(f"**Interests:** {', '.join(person.get('interests', [])) or 'N/A'}")

                    # Display milestones if available
                    if "milestones" in person and person["milestones"]:
                        st.markdown("### Milestones:")
                        for milestone in person["milestones"]:
                            st.markdown(f"- **{milestone['type']}**: {datetime.strptime(milestone['date'], '%Y-%m-%d').strftime('%B %d, %Y')}")
                else:
                    st.error("No profile found.")
            except Exception as e:
                st.error(f"Error: {e}")

        # View and Export Milestones
        milestones_key = f"{name}_milestones"
        if st.button("Export Milestones", key="view_milestones"):
            try:
                person = family_collection.find_one({"name": name}, {"milestones": 1})
                if person and "milestones" in person:
                    milestones = person["milestones"]
                    # Store milestones in session state for persistence
                    st.session_state[milestones_key] = milestones
                    st.success("Milestones loaded successfully!")
                else:
                    st.error("No milestones found.")
            except Exception as e:
                st.error(f"Error: {e}")

        if milestones_key in st.session_state:
            milestones = st.session_state[milestones_key]
            milestone_options = {f"{m['type']} on {datetime.strptime(m['date'], '%Y-%m-%d').strftime('%B %d, %Y')}": m for m in milestones}
            selected = st.selectbox("Select a milestone to export:", list(milestone_options.keys()), key="select_milestone")

            if st.button("Export to .ics", key="export_ics"):
                try:
                    calendar = Calendar()
                    milestone = milestone_options[selected]
                    event = Event()
                    event.name = milestone["type"]
                    event.begin = milestone["date"]
                    calendar.events.add(event)

                    # Save and offer the file for download
                    file_path = f"{name}_milestone.ics"
                    with open(file_path, "w") as file:
                        file.writelines(calendar.serialize())
                    st.success("Milestone exported successfully!")
                    with open(file_path, "rb") as file:
                        st.download_button("Download .ics", data=file, file_name=file_path)
                except Exception as e:
                    st.error(f"Error: {e}")
    else:
        st.error("MongoDB is not connected. Please check your connection.")

# Tab 2: Neo4j Queries
with tab2:
    st.header("Family Relationships")   
    # Add a clickable link to the Neo4j Browser
    st.markdown("""
    ### 🌐 Access Neo4j Browser
    [Click here to access the Neo4j Browser](http://localhost:7474)
    """, unsafe_allow_html=True)

    member_name = st.text_input("Enter Family Member's Name for Queries")

    # 1. Find all descendants of a family member
    if st.button("Find All Descendants"):
        query = """
        MATCH (p:Person {name: $name})-[:PARENT*]->(descendant:Person)
        RETURN descendant.name AS name, descendant.gender AS gender
        ORDER BY name
        """
        try:
            descendants = neo4j_conn.query(query, parameters={"name": member_name})
            if descendants:
                st.markdown("### Descendants:")
                st.write(pd.DataFrame(descendants))
            else:
                st.error("No descendants found.")
        except Exception as e:
            st.error(f"Error: {e}")

    # 2. Retrieve siblings of a family member
    if st.button("Retrieve Siblings"):
        query = """
        MATCH (p:Person {name: $name})-[:SIBLING]-(sibling:Person)
        RETURN sibling.name AS sibling_name, sibling.gender AS gender
        """
        try:
            siblings = neo4j_conn.query(query, parameters={"name": member_name})
            if siblings:
                st.markdown("### Siblings:")
                st.write(pd.DataFrame(siblings))
            else:
                st.error("No siblings found.")
        except Exception as e:
            st.error(f"Error: {e}")

    # 3. Get spouse of a family member
    if st.button("Get Spouse"):
        query = """
        MATCH (p:Person {name: $name})-[:SPOUSE]-(spouse:Person)
        RETURN spouse.name AS spouse_name, spouse.gender AS gender
        """
        try:
            spouse = neo4j_conn.query(query, parameters={"name": member_name})
            if spouse:
                st.markdown("### Spouse:")
                st.write(pd.DataFrame(spouse))
            else:
                st.error("No spouse found.")
        except Exception as e:
            st.error(f"Error: {e}")

    # 4. Find common ancestors between 2 members
    member_name2 = st.text_input("Enter Second Family Member's Name for Common Ancestors")
    if st.button("Find Common Ancestors"):
        query = """
        MATCH (a:Person {name: $name1})-[:PARENT*]->(common_ancestor:Person)<-[:PARENT*]-(b:Person {name: $name2})
        RETURN DISTINCT common_ancestor.name AS common_ancestor_name, common_ancestor.gender AS gender
        """
        try:
            common_ancestors = neo4j_conn.query(query, parameters={"name1": member_name, "name2": member_name2})
            if common_ancestors:
                st.markdown("### Common Ancestors:")
                st.write(pd.DataFrame(common_ancestors))
            else:
                st.error("No common ancestors found.")
        except Exception as e:
            st.error(f"Error: {e}")

    # 5. Retrieve extended family members (cousins, aunts, uncles, etc.)
    if st.button("Retrieve Extended Family"):
        query = """
        MATCH (p:Person {name: $name})-[:PARENT*1..2]-(extended_family:Person)
        WHERE NOT (p)-[:PARENT|SIBLING|SPOUSE]-(extended_family)
        RETURN DISTINCT extended_family.name AS name, extended_family.gender AS gender
        """
        try:
            extended_family = neo4j_conn.query(query, parameters={"name": member_name})
            if extended_family:
                st.markdown("### Extended Family:")
                st.write(pd.DataFrame(extended_family))
            else:
                st.error("No extended family found.")
        except Exception as e:
            st.error(f"Error: {e}")

    # 6. Get full family tree from a member
    if st.button("Get Full Family Tree"):
        query = """
        MATCH (root:Person {name: $name})-[:PARENT*]->(descendant:Person)
        RETURN root.name AS root, descendant.name AS descendant, descendant.gender AS gender
        """
        try:
            family_tree = neo4j_conn.query(query, parameters={"name": member_name})
            if family_tree:
                st.markdown("### Full Family Tree:")
                graph = nx.DiGraph()
                for record in family_tree:
                    graph.add_edge(record["root"], record["descendant"])
                
                if graph.number_of_edges() > 0:
                    # Generate the Pyvis network graph
                    net = Network(notebook=False, directed=True, height="750px", width="100%")
                    net.from_nx(graph)

                    # Save the graph as an HTML string
                    net_html = net.generate_html()

                    # Embed the HTML in the Streamlit app
                    st.components.v1.html(net_html, height=800)
                    st.success("Family tree displayed successfully!")
                else:
                    st.error("No connections found in the family tree.")
            else:
                st.error("No family tree found.")
        except Exception as e:
            st.error(f"Error: {e}")

    # 7. Add a parent-child relationship
    parent_name = st.text_input("Enter Parent's Name")
    child_name = st.text_input("Enter Child's Name")
    if st.button("Add Parent-Child Relationship"):
        query = """
        MATCH (parent:Person {name: $parent_name}), (child:Person {name: $child_name})
        CREATE (parent)-[:PARENT]->(child)
        RETURN parent.name AS parent, child.name AS child
        """
        try:
            # Verify both nodes exist
            verify_query = """
            MATCH (parent:Person {name: $parent_name}), (child:Person {name: $child_name})
            RETURN parent.name AS parent, child.name AS child
            """
            exists = neo4j_conn.query(verify_query, parameters={"parent_name": parent_name, "child_name": child_name})
            if not exists:
                st.error("Parent or child node does not exist. Please ensure both nodes are in the database.")
            else:
                relationship = neo4j_conn.query(query, parameters={"parent_name": parent_name, "child_name": child_name})
                if relationship:
                    st.success(f"Successfully added parent-child relationship: {parent_name} → {child_name}")
                else:
                    st.error("Failed to add parent-child relationship.")
        except Exception as e:
            st.error(f"Error: {e}")


# Tab 3: Redis Pub/Sub
with tab3:
    st.header("Family Forum")

    # Publish a message
    st.subheader("Post a Message")
    channels = st.multiselect("Select Channels", options=["family_forum", "birthdays", "generations", "family_reunion"])
    message = st.text_input("Your Message")
    if st.button("Post Message"):
        if channels and message:
            for channel in channels:
                redis_client.publish(channel, message)
            st.success("Message posted successfully!")
        else:
            st.error("Please select channels and enter a message.")

    # Subscribe to messages
    st.subheader("Subscribe to Messages")
    subscribe_channels = st.multiselect("Subscribe to Channels", options=["family_forum", "birthdays", "generations", "family_reunion"])
    if st.button("Start Subscription"):
        if subscribe_channels:
            pubsub.subscribe(subscribe_channels)
            st.success(f"Subscribed to: {', '.join(subscribe_channels)}")

            # Listening to Redis messages in a background thread
            def listen_to_messages():
                for message in pubsub.listen():
                    if message["type"] == "message":
                        st.write(f"[{message['channel'].upper()}]: {message['data']}")

            threading.Thread(target=listen_to_messages, daemon=True).start()
        else:
            st.error("Please select at least one channel to subscribe.")

# Close Neo4j connection on exit
st.sidebar.button("Exit", on_click=neo4j_conn.close)

