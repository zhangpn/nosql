# 🌳 TreeHouse: Family Tree Application

TreeHouse is a powerful application designed to manage, explore, and visualize family relationships. It integrates MongoDB, Neo4j, Redis, and Flask, bringing the power of NoSQL databases and graph databases together in a seamless user interface built with Streamlit. The app allows users to query family member profiles, manage relationships, and explore an interactive family tree—all in one place.

---

## 🚀 Project Components and Technologies

1. **MongoDB**: Stores family member profiles and related details such as birthdays, occupations, and milestones.
2. **Neo4j**: Graph database to model and query family relationships (e.g., parent-child, siblings, etc.).
3. **Redis**: Implements a Pub/Sub mechanism for a forum feature and caching frequently accessed data.
4. **Flask**: RESTful API for interacting with MongoDB and Neo4j, enabling CRUD operations and data retrieval.
5. **Streamlit**: A user-friendly, intuitive UI to bring all components together into a single prototype.

---

## 🛠 Why MongoDB, Neo4j, and Redis?

- **MongoDB**: Perfect for storing document-like family member profiles. Its schema-less nature makes it flexible for evolving data.
- **Neo4j**: Best for representing and querying relationships as graphs, enabling operations like finding ancestors, descendants, and extended family members efficiently.
- **Redis**: Provides real-time communication through Pub/Sub and speeds up queries with caching.

---

## 📄 How to Produce Results

### ⚙️ Set Up and Test Components Individually

1. **Clone the Repository:**
   - git clone <https://github.com/Sainandini07/NoSQL-FinalProject.git>
    - Clone this into a directory where it is mounted in Docker
   - cd <NoSQL-FinalProject>
     - Entire file path referred to as 'directory' onwards
       - Whenever working in terminal, always be in directory

2. **Build the Docker Containers:**
   - Ensure docker-compose.yml file paths match to your directory
     - Left-hand side of : for all containers should be file path of parent folder
     - Note if using Mac, uncomment the 'restart' line in the MongoDB container
   - Open Docker Desktop
   - Open a new terminal and cd into directory
     - docker compose up --build
     - Double check all containers are running in Docker Desktop
        - If not, press the play button to start it

3. **MongoDB Setup:**
    - Curate data
        - python mongo_insertion.py in terminal
    - Import family data into MongoDB
        - docker exec -it mongodb sh
        - mongoimport --db treehouse --collection family_members --file /data/db/family_members.json --jsonArray --mode upsert 
    - For Mac users- please make sure to keep the family_members.json file is inside the mongo_data directory and for windows, please make sure the family_members.json file is outside the mongo_data directory. We had to do it due to laptop constraints. 
    - Test MongoDB queries using Postman & app.py
        - Start the Flask app
            - python app.py in terminal
        - Open Postman and test the following endpoints
            - Welcome Page
                - GET http://127.0.0.1:8090
            - Retrieve personal profile information
                - GET http://127.0.0.1:8090/api/profile?name=Isabella%20King
            - Query family members with specific occupation
                - GET http://127.0.0.1:8090/api/occupation?occupation=Chef
            - Retrieve all family members with pets
                - GET http://127.0.0.1:8090/api/has-pets
            - Obtain a family member's favorite color
                - GET http://127.0.0.1:8090/api/favorite-color?name=Isabella%20King
            - Retrieve family member's hobbies
                - GET http://127.0.0.1:8090/api/hobbies?name=Isabella%20King
            - Update favorite color
                - PUT http://127.0.0.1:8090/api/favorite-color?name=Isabella%20King
                - JSON Body: {"favorite_color":"Teal"}
            - Remove pet status
                - DELETE http://127.0.0.1:8090/api/has-pet?name=Isabella%20King
            - Obtain all milestones of a family member
                - GET http://127.0.0.1:8090/api/milestones?name=Isabella%20King
            - Save selected milestones to a .ics
                - POST http://127.0.0.1:8090/api/milestones/ics?name=Isabella%20King
                - JSON Body: {"milestones": ["Birthday"]}

4. **Neo4j Setup:**
    - Populate the graph database with nodes and relationships
        - Open the neo4j_population.ipynb notebook and run all cells.
    - Test Neo4j queries in the notebook
        - Find all descendants of a family member
        - Retrieve siblings of a family member
        - Get spouse of a family member
        - Find common ancestors between 2 members
        - Retrieve extended family members (i.e. cousins, aunts, uncles, etc.)
        - Get full family tree from a member
        - Add a parent-child relationship

5. **Redis Setup:**
    - docker exec -it streamlit_ui bash in terminal    
    - Start the redis chatroom
        - Before running redis_queries.py file, use host = 'redis' for Macbook and host = 'localhost' for Windows in the function below
        ```bash
        class FamilyChatbot:
            def __init__(self, host='redis', port=6379):
        ``` 
        - Type 'python redis_queries.py' to start the chatroom
    - Monitor redis activity
        - docker exec -it redis redis-cli in terminal
        - Type 'monitor'
    - Test the commands
        - In terminal where we're running the redis_queries.py, run the following commans:
            - !help 
            - !identify (identify the user with name, age, relation to the family and location)
            - !whoami (to test the verify details)
            - !join channels
                - You: !join family_forum,birthdays
            - !leave channels
                - You: !leave family_forum
            - !message channels
                - You: !message family_reunion Hi everyone!
            - !addmilestone
                - You: !addmilestone Meenu Birthday 2003-05-27
            - !listen 
                - You: !listen
            - !dm
                - You: !dm Meenu Happy Birthday!
            - !search
                - You : !search Alice

6. **Stop the Docker Containers:**
    - Open a new terminal and in the directory type 'docker compose down'
        - This will stop all docker containers
    - Quit the Docker Desktop application

---

### 🖥 Run the Streamlit Application

1. **Start Streamlit:**
   - Should be already started when Docker containers are initialized, but if it isn't, restart the container in the terminal:
    - docker compose restart streamlit

2. **Access the App:**
   - Open your browser and go to http://localhost:8501

3. **Features:**
   - View MongoDB family queries.
   - Explore Neo4j Queries.
   - Use Redis for real-time family forums.

---

## 🔍 Queries to Test

### 🟢 MongoDB

1. Search Profile
2. Query Members by Occupation
3. Retrieve Members with Pets
4. Favorite Color
5. Retrieve Members' Hobbies
6. Update Favorite Color
7. Remove Pet Status
8. View Milestones
9. Save Milestones to .ics

### 🔵 Neo4j

10. Find All Descendants
11. Retrieve Siblings
12. Get Spouse
13. Find Common Ancestors
14. Retrieve Extended Family
15. Get Full Family Tree
16. Add Parent-Child Relationship

### 🔴 Redis

17. Join the Channels 
18. Leave Channels
19. Send Messages
20. Add Milestones
21. Listen to Messages from Subscribed Channel
22. Send Direct Messages from One User to Another
23. Search the User Details

---

## 📋 Additional Notes
1. Modular Design:
    - MongoDB for data storage.
    - Neo4j for relationship management.
    - Redis for forum-style communication.

2. Future Enhancements:
    - Integrate privacy & security features so user can only see their family.
    - Add more functionalities to streamlit UI
        - Message directly on UI
            - Need to save messages in Redis

---

## 🏗 Project Structure

TreeHouse/
├── app.py                   # Flask app for MongoDB and Neo4j APIs
├── treehouse_app.py         # Streamlit UI
├── neo4j_population.ipynb   # Neo4j node and relationship creation
├── mongo_insertion.py       # MongoDB data insertion script
├── family_members.json      # Sample data for MongoDB
├── Dockerfile               # Docker configuration for Streamlit
├── docker-compose.yml       # Docker Compose file for all services
├── requirements.txt         # Python dependencies

## Generative AI Usage

This project used AI to:

- Generate helper functions to automatically curate data
- Troubleshoot & resolve runtime errors, connection issues, & unexpected behavior across streamlit
- Optimize existing code for better performance
- Guided how to export milestones to .ics
- Validated all AI-generated outputs to ensure accuracy

## 🎉 Enjoy TreeHouse!

Feel free to explore, query, and manage your family tree with ease! 🌟
