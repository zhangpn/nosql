from flask import Flask, jsonify, request, Response
from pymongo import MongoClient
from ics import Calendar, Event
from datetime import datetime

app = Flask(__name__)

# MongoDB Connection
mongo_client = MongoClient("mongodb://localhost:27017/")
mongo_db = mongo_client["treehouse"]
family_collection = mongo_db["family_members"]

# -------------------------------------------
# Milestones and .ics functionality
# -------------------------------------------
 
# GET all milestones for a family member
# Example: GET http://127.0.0.1:8090/api/milestones?name=Isabella%20King
@app.route("/api/milestones", methods=["GET"])
def get_milestones():
    name = request.args.get("name")
    if not name:
        return jsonify({"error": "Please provide a name parameter, e.g., ?name=Alice"}), 400

    person = family_collection.find_one({"name": name}, {"milestones": 1})
    if not person or "milestones" not in person:
        return jsonify({"error": f"No milestones found for name: {name}"}), 404

    return jsonify({"name": name, "milestones": person["milestones"]})


# POST to save selected milestones as a .ics file
# Example: POST http://127.0.0.1:8090/api/milestones/ics?name=Isabella%20King
# Body: {"milestones": ["Birthday"]}
@app.route("/api/milestones/ics", methods=["POST"])
def save_milestones_as_ics():
    name = request.args.get("name")
    selected_milestones = request.json.get("milestones")

    if not name or not selected_milestones:
        return jsonify({"error": "Please provide a name and milestones to save."}), 400

    person = family_collection.find_one({"name": name}, {"milestones": 1})
    if not person or "milestones" not in person:
        return jsonify({"error": f"No milestones found for name: {name}"}), 404

    milestones = [
        milestone
        for milestone in person["milestones"]
        if milestone["type"] in selected_milestones
    ]

    if not milestones:
        return jsonify({"error": "No matching milestones found to save."}), 404

    calendar = Calendar()
    for milestone in milestones:
        event = Event()
        event.name = milestone["type"]
        event.description = f"{milestone['type']} for {name}"
        event.begin = milestone["date"]

        if milestone["type"] in ["Birthday", "Wedding Anniversary"]:
            event.make_all_day()
            event.rrule = "FREQ=YEARLY"

        calendar.events.add(event)

    ics_file = calendar.serialize()
    response = Response(ics_file, mimetype="text/calendar")
    response.headers["Content-Disposition"] = f"attachment; filename={name}_selected_milestones.ics"
    return response

# -------------------------------------------
# API Endpoints
# -------------------------------------------

# Welcome Endpoint
# GET http://127.0.0.1:8090
@app.route("/")
def index():
    return jsonify({"message": "Welcome to the Treehouse App! Explore the family tree via MongoDB APIs."})


# 1. Retrieve personal profile information from the data (MongoDB)
# Example URL in Postman: GET http://127.0.0.1:8090/api/profile?name=Isabella%20King
@app.route("/api/profile")
def get_personal_profile():
    name = request.args.get("name")
    if not name:
        return jsonify({"error": "Please provide a name parameter, e.g., ?name=Alice"}), 400
    person = family_collection.find_one({"name": name})
    if person:
        person["_id"] = str(person["_id"])  # Convert ObjectId to string
        return jsonify(person)
    else:
        return jsonify({"error": f"No profile found for name: {name}"}), 404


# 2. Query family members with specific occupations
# Example URL in Postman: GET http://127.0.0.1:8090/api/occupation?occupation=Chef
@app.route("/api/occupation")
def get_by_occupation():
    occupation = request.args.get("occupation")
    if not occupation:
        return jsonify({"error": "Please provide an occupation parameter, e.g., ?occupation=Engineer"}), 400
    members = list(family_collection.find({"occupation": occupation}))
    for member in members:
        member["_id"] = str(member["_id"])  # Convert ObjectId to string
    return jsonify(members)


# 3. Retrieve family members with pets
# Example URL in Postman: GET http://127.0.0.1:8090/api/has-pets
@app.route("/api/has-pets")
def get_with_pets():
    members = list(family_collection.find({"has_pet": True}))
    for member in members:
        member["_id"] = str(member["_id"])  # Convert ObjectId to string
    return jsonify(members)


# 4. Get favorite color of a family member
# Example URL in Postman: GET http://127.0.0.1:8090/api/favorite-color?name=Isabella%20King
@app.route("/api/favorite-color")
def get_favorite_color():
    name = request.args.get("name")
    if not name:
        return jsonify({"error": "Please provide a name parameter, e.g., ?name=Alice"}), 400
    person = family_collection.find_one({"name": name}, {"favorite_color": 1})
    if person and "favorite_color" in person:
        return jsonify({"name": name, "favorite_color": person["favorite_color"]})
    else:
        return jsonify({"error": f"No favorite color found for name: {name}"}), 404


# 5. Retrieve hobbies of a family member
# Example URL in Postman: GET http://127.0.0.1:8090/api/hobbies?name=Isabella%20King
@app.route("/api/hobbies")
def get_hobbies():
    name = request.args.get("name")
    if not name:
        return jsonify({"error": "Please provide a name parameter, e.g., ?name=Alice"}), 400

    person = family_collection.find_one({"name": name}, {"interests": 1})  # Corrected from "hobbies" to "interests"
    if person and "interests" in person:
        return jsonify({"name": name, "hobbies": person["interests"]})
    else:
        return jsonify({"error": f"No hobbies found for name: {name}"}), 404


# 6. Update a family member's favorite color
# PUT to update a family member's favorite color
# Example: PUT http://127.0.0.1:8090/api/favorite-color?name=Isabella%20King
# Body: {"favorite_color":"Teal"}
@app.route("/api/favorite-color", methods=["PUT"])
def update_favorite_color():
    name = request.args.get("name")
    new_color = request.json.get("favorite_color")

    if not name or not new_color:
        return jsonify({"error": "Please provide a name and a new favorite color."}), 400

    result = family_collection.update_one(
        {"name": name},
        {"$set": {"favorite_color": new_color}}
    )

    if result.matched_count == 0:
        return jsonify({"error": f"No family member found with name: {name}"}), 404

    return jsonify({"message": f"Favorite color updated successfully for {name}."})


# 7. Remove a family member's pet status
# DELETE to remove the 'has_pet' field for a family member
# Example: DELETE http://127.0.0.1:8090/api/has-pet?name=Isabella%20King
@app.route("/api/has-pet", methods=["DELETE"])
def delete_pet_status():
    name = request.args.get("name")

    if not name:
        return jsonify({"error": "Please provide a name to delete pet status."}), 400

    result = family_collection.update_one(
        {"name": name},
        {"$unset": {"has_pet": ""}}
    )

    if result.matched_count == 0:
        return jsonify({"error": f"No family member found with name: {name}"}), 404

    return jsonify({"message": f"Pet status removed successfully for {name}."})

# -------------------------------------------
# Run the App
# -------------------------------------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8090)
