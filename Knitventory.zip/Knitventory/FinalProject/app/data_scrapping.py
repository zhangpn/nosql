# %% [markdown]
# ## Data Preparation
# ### Web Scraping on Yarn data
# Using the data from the `yarn.com`. I will scrap the data that fiber artists usually looked for while searching for yarn
# - net_weight 
# - yarn_blend: 
# - brand
# - yarn_length
# - tension_gauge 
# - yarn_weight: 
# - care:
# - suggested_crochet_hook:
# - suggested_needles: 
# - inventory: (Optional)
#     - total_quantities
#     - total_length:
#     - color: 
# 
# The idea here is that the data would be converted into JSON file. Every time when a new link from yarn.com is being added, it will then appended to the `yarn_db.json` 
# 

# %%
import requests
from bs4 import BeautifulSoup
import json
import os 
import re


# %%
def get_yarn_data(url): 
    # Make a GET request to fetch the HTML content of the page
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')
        # Initialize a dictionary to store the data
        yarn_data = {}

        try:
            # Extract the full page title from the `<title>` tag
            page_title = soup.find('title').text.strip()
            yarn_data['url'] = url
            # Extract the brand name using the `Brand` field
            def get_field_value(testid):
                element = soup.find('div', {'data-testid': testid})
                if element:
                    return element.find('dd', class_='sf-property__value').text.strip()
                return None
            
            # Extract brand name and yarn name
            brand = get_field_value("Brand")
            if brand:
                yarn_data['brand'] = brand
                
                # Remove the brand name and other known suffixes from the title
                yarn_data['yarn_name'] = page_title.replace(f"{brand} ", "").replace("Yarn at WEBS | Yarn.com", "").strip()
            else:
                # Fallback if brand extraction fails
                yarn_data['yarn_name'] = page_title.replace("Yarn at WEBS | Yarn.com", "").strip()

            # Extract and format the other fields
            net_weight = get_field_value("Net Weight")
            if net_weight:
                weight_parts = re.findall(r'([\d.]+)([a-zA-Z]+)', net_weight)
                yarn_data['net_weight'] = {
                    "gram": float(weight_parts[0][0]) if weight_parts else None,
                    "oz": float(weight_parts[1][0]) if len(weight_parts) > 1 else None
                }

            yarn_blend = get_field_value("Blend")
            yarn_data['yarn_blend'] = yarn_blend

            yarn_length = get_field_value("Length")
            if yarn_length:
                length_parts = re.findall(r'([\d.]+)[a-zA-Z]*\s*\(([\d.]+)[a-zA-Z]*\)', yarn_length)
                if length_parts:
                    yarn_data['yarn_length'] = {
                        "yard": float(length_parts[0][0]),
                        "meter": float(length_parts[0][1])
                    }

            suggested_needles = get_field_value("Needles")
            if suggested_needles:
                needle_match = re.match(r'US\s*(\d+)\s*\(([\d.]+)\s*mm\)', suggested_needles)
                if needle_match:
                    yarn_data['suggested_needles'] = {
                        "US size": int(needle_match.group(1)),
                        "international_size_mm": float(needle_match.group(2))
                    }

            suggested_hooks = get_field_value("Crochet Hooks")
            if suggested_hooks:
                hook_match = re.match(r'US\s*([A-Z])\s*\(([\d.]+)\s*mm\)', suggested_hooks)
                if hook_match:
                    yarn_data['suggested_hooks'] = {
                        "US size": hook_match.group(1),
                        "international_size_mm": float(hook_match.group(2))
                    }

            yarn_data['care'] = get_field_value("Care")
            yarn_data['tension_gauge'] = get_field_value("Tension")
            # valid yarn weight
            valid_yarn_weights = [
                "thread", "cobweb", "lace", "light fingering", "fingering", "sport",
                "dk", "worsted", "aran", "bulky", "super bulky", "jumbo"
            ]
            # Function to retrieve and validate the yarn weight
            def get_valid_yarn_weight(testid):
                # Get the field value using the existing logic
                yarn_weight = get_field_value(testid)
                
                # Extract the first part before a space if the value exists
                yarn_weight = yarn_weight.split(' ')[0].lower() if yarn_weight else None

                # Check if the yarn weight matches any valid weight
                if yarn_weight in valid_yarn_weights:
                    return yarn_weight
                else:
                    return "Unknown"
            yarn_data['yarn_weight'] = get_valid_yarn_weight("Yarn Weight")
        except Exception as e:
            print("Error extracting one or more fields:", e)
    else:     
        print(f"Failed to retrieve the webpage. Status code: {response.status_code}")

    return yarn_data

# %%
def save_yarn_data(json_file, url, method):
    # Scrape the yarn data from the URL
    json_data = method(url)
    if not json_data:
        print("No data scraped.")
        return

    # Check if the JSON file exists
    if not os.path.exists(json_file):
        # Create the JSON file with an empty list
        with open(json_file, 'w') as file:
            json.dump([], file)

    # Check if the file is empty or invalid
    try:
        with open(json_file, 'r') as file:
            data = json.load(file)
    except json.JSONDecodeError:
        # Initialize with an empty list if JSONDecodeError occurs
        data = []

    # Append the new yarn data to the list
    data.append(json_data)

    # Save the updated data back to the JSON file
    with open(json_file, 'w') as file:
        json.dump(data, file, indent=4)

    print(f"Data successfully added to {json_file}")

# %%
# Example usage
"""
urls = ["https://www.yarn.com/products/string-turin","https://www.yarn.com/products/valley-yarns-huntington"]

current_wd = os.getcwd()
json_file_data = os.path.join(current_wd, "data", "yarn_db.json")

for url in urls:
    print(url)
    save_yarn_data(json_file_data, url, get_yarn_data)
"""
# %% [markdown]
# ### Content Scraping on PDF data
# This section will scrap data from Ravelry site
# - pattern_name: 
# - author_name: 
# - category: 
# - subcategory: 
# - suggested_yarn: 
# - yarn_weight: 
# - min_yarn_requirement 
# - max_yarn_requirement
# - gauge 
# - needle_size: 
# - hook_size: 
# - size: 
# - techniques: 
# 

# %%
def get_pattern_data(url):
    # Fetch the HTML content from the URL
    response = requests.get(url)
    if response.status_code != 200:
        print(f"Failed to retrieve the webpage. Status code: {response.status_code}")
        return None

    soup = BeautifulSoup(response.content, 'html.parser')
    # Initialize the dictionary to store extracted data
    pattern_data = {}
    try:
        # extract url 
        pattern_data['url'] = url
        # Extract pattern name
        pattern_data['pattern_name'] = soup.find('h2', class_='rsp_hidden').text.strip()


        # Extract author name
        author = soup.find('div', class_='pattern_author')
        pattern_data['author_name'] = author.find('a').text.strip() if author else None

        # Extract category and subcategory
        category = soup.find('div', class_='category')
        if category:
            spans = category.find_all('span')
            pattern_data['category'] = {
                'main': spans[0].text.strip() if len(spans) > 0 else None,
                'subcategory': spans[1].text.strip() if len(spans) > 1 else None
            }
        else:
            pattern_data['category'] = {
                'main': None,
                'subcategory': None
            }

        # Extract suggested yarns
        yarn_elements = soup.find_all('div', class_='value core_item_content__value')
        pattern_data['suggested_yarn'] = [yarn.text.strip() for yarn in yarn_elements]

        # Extract yarn weight
        find_yarn_weight = soup.find('label', string=re.compile(r'Yarn weight', re.IGNORECASE))
        # Yarn weight categories to check against
        valid_yarn_weights = [
            "thread", "cobweb", "lace", "light fingering", "fingering", "sport", 
            "dk", "worsted", "aran", "bulky", "super bulky", "jumbo"
        ]
        yarn_weight_value = None

        if find_yarn_weight:
            # Iterate through sibling 'div' elements after the label
            for sibling in find_yarn_weight.find_all_next('div', class_='value'):
                # Clean the text of the current div
                cleaned_value = sibling.text.replace('\n', '').replace('\t', '').strip().lower()

                # Check if the cleaned value contains any valid yarn weight
                for weight in valid_yarn_weights:
                    if weight in cleaned_value:
                        yarn_weight_value = weight  # Update with the exact weight
                        break

        # Assign to the pattern_data dictionary or handle no match case
        if yarn_weight_value:
            pattern_data['yarn_weight'] = yarn_weight_value
        else:
            pattern_data['yarn_weight'] = "Unknown" 

        # Extract yarn requirements
        yardage = soup.find('label', string=re.compile(r'Yardage', re.IGNORECASE))
        if yardage:
            yardage_value = yardage.find_next('div', class_='value').text.strip() if yardage else None
            yard_match = re.search(r'(\d+)\s*-\s*(\d+)\s*yards?', yardage_value)
            meter_match = re.search(r'(\d+)\s*-\s*(\d+)\s*m', yardage_value)

            if yard_match and meter_match:
                # Extract min and max values for yards and meters
                min_yard, max_yard = map(int, yard_match.groups())
                min_meter, max_meter = map(int, meter_match.groups())
                pattern_data['min_yarn_requirement'] = {'yard': min_yard, 'meter': min_meter}
                pattern_data['max_yarn_requirement'] = {'yard': max_yard, 'meter': max_meter}
            else:
                # Set to None if matches are not found
                pattern_data['min_yarn_requirement'] = {'yard': None, 'meter': None}
                pattern_data['max_yarn_requirement'] = {'yard': None, 'meter': None}
        else:
            pattern_data['min_yarn_requirement'] = {'yard': None, 'meter': None}
            pattern_data['max_yarn_requirement'] = {'yard': None, 'meter': None}

        # Extract gauge
        gauge = soup.find('label', string=re.compile(r'Gauge', re.IGNORECASE))
        pattern_data['gauge'] = gauge.find_next('div', class_='value').text.strip() if gauge else None

        # Extract needle size

        needle_label = soup.find('label', string=re.compile(r'Needle size', re.IGNORECASE))
        if needle_label:
            needle_values = []
            # Get the parent container of the label to find all relevant values
            parent_div = needle_label.find_parent('div', class_='field core_item_content__field')
            if parent_div:
                needle_values = [div.text.strip() for div in parent_div.find_all('div', class_='value')]
                pattern_data['needle_size'] = needle_values
            else: 
                pattern_data['needle_size'] = []

        else:
            pattern_data['needle_size'] = []

        # Extract hook size
        hook_label = soup.find('label', string=re.compile(r'Hook size', re.IGNORECASE))
        if hook_label:
            hook_values = []
            # Get the parent container of the label to find all relevant values
            parent_div = hook_label.find_parent('div', class_='field core_item_content__field')
            if parent_div:
                hook_values = [div.text.strip() for div in parent_div.find_all('div', class_='value')]
                pattern_data['hook_size'] = hook_values
            else: 
                pattern_data['hook_size'] = []

        else:
            pattern_data['hook_size'] = []

        # Extract sizes available
        sizes = soup.find('label', string=re.compile(r'Sizes available', re.IGNORECASE))
        pattern_data['size'] = sizes.find_next('div', class_='value').text.strip() if sizes else None

        # Extract pattern properties
        tags = soup.find('ul', class_='tag_set')
        if tags:
            # Extract all properties
            all_properties = [tag.text.strip() for tag in tags.find_all('a')]

            # Define regex to match unwanted patterns
            unwanted_pattern = re.compile(r'\d+\s+more\s+attributes\.{3}', re.IGNORECASE)
            unwanted_properties = {'unisex', 'female', 'adult', 'men', 'search patterns with these attributes', 'show less...'}

            # Filter out unwanted properties using regex and the set of unwanted terms
            pattern_data['pattern_properties'] = [
                prop for prop in all_properties
                if prop.lower() not in unwanted_properties and not unwanted_pattern.match(prop)
            ]
        else:
            pattern_data['pattern_properties'] = []

    except Exception as e:
        print("Error extracting data:", e)
        return None

    return pattern_data

"""
# %%
ravelry_urls = ["https://www.ravelry.com/patterns/library/poppy-tee-3", "https://www.ravelry.com/patterns/library/blouse-no-1"]
pattern_json_file = os.path.join(current_wd, "data", "pattern_db.json")

for url in ravelry_urls:
    save_yarn_data(pattern_json_file, url, get_pattern_data)

# %%
"""


