'''Module for serving API requests'''
from app import app
from flask import Flask, request, jsonify
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime
from app.data_scrapping import get_yarn_data, get_pattern_data
from app.utils import parse_query_params
import os 
import json

# 1. Connect to MongoDB client
client = MongoClient(host="localhost", port=27017)
# 2. Select the database and collection
db = client.knittinghub  # 'use knittinghub'
yarn_collection = db.yarn  # collection: all sorts of yarn that is not limited to your inventory
pattern_collection = db.pattern  # collection: pattern that you own
yarn_inventory_collection = db.inventory  # collection: inventory of yarn
output_dir = "collection_backups"
os.makedirs(output_dir, exist_ok=True)

# find next id 
def find_next_id(collection, id_field):
    """
    Finds the next available ID for the given collection by identifying gaps in the sequence.
    If no gaps are found, returns max(id) + 1.
    """
    # Get all IDs from the collection and sort them
    all_ids = sorted([doc[id_field] for doc in collection.find({}, {id_field: 1})])

    # Check for the first missing ID in the sequence
    for i, id_val in enumerate(all_ids, start=1):
        if id_val != i:
            return i  # Return the missing ID

    # If no gaps are found, return the next ID after the current maximum
    return len(all_ids) + 1

######## HomePage
@app.route("/", methods=['GET'])  # For the default root URL ('/')
def get_initial_response():
    """
    Homepage: Welcom to Trang's KnittingHub API
    """
    message = {
        'apiVersion': 'v1.0',
        'status': '200',
        'message': 'Welcome to KnittingHub API'
    }
    return jsonify(message), 200

#### Import json data to mongodb 
## call example http://127.0.0.1:5000/import/json?collection_name=yarn 
@app.route("/import/json", methods=['GET'])
def import_json_to_mongodb():
    """
    Import a JSON array into MongoDB with checks for collection existence and count comparison.

    Parameters:
    - collection_name: The name of the collection.
    - json_file_path: Path to the JSON file containing the data.

    Returns:
    - None
    """
    try:
        # 
        raw_query_string = request.query_string
        # Get all query parameters from the request
        query_params = parse_query_params(raw_query_string)
        collection_name = query_params['collection_name']
        if collection_name not in ['yarn', 'pattern', 'inventory']:
            return jsonify({'message': 'Invalid collection name. Must be "yarn", "pattern", or "inventory".'}), 400
        if not collection_name: 
            return jsonify({'message': 'Please provide collection_name. Must be "yarn", "pattern", or "inventory"'}), 400
        json_file = os.path.join(output_dir, f"{collection_name}.json")
        # Connect to MongoDB
        collection = db[collection_name]

        # Load JSON array from the file
        with open(json_file, "r") as file:
            json_data = json.load(file)

        if not isinstance(json_data, list):
            return jsonify({'message': 'The JSON file does not contain a valid JSON array.'}), 400
    

        # Check if the collection already exists
        if collection_name in db.list_collection_names():
            # Collection exists, compare document count
            mongo_count = collection.count_documents({})
            json_count = len(json_data)

            if mongo_count > json_count:
                return jsonify({'message': 'Error: Your JSON array is out of date. MongoDB collection has more documents than the JSON array.'}), 400
            
            elif json_count > mongo_count:
                # Replace MongoDB collection with JSON data
                collection.delete_many({})  # Clear the collection
                result = collection.insert_many(json_data)  # Insert the JSON data
                return jsonify({'warning': 'Your MongoDB collection was out of date. Replaced with JSON data.',
                    'message': f'Replaced collection "{collection_name}" with JSON data.'}), 200
            else:
                return jsonify({'message': 'JSON array and MongoDB collection have the same document count. No action needed.'}), 200
        else:
            # Collection does not exist; insert the JSON data
            result = collection.insert_many(json_data)
            return jsonify({'message': f'Inserted {len(result.inserted_ids)} documents into the collection "{collection_name}".'}), 201

    except Exception as e:
        return jsonify({'message': f'An error occurred: {str(e)}'}), 500

####### 1. Add yarn new information to database with 1 or multipl,e url links
@app.route("/add/url", methods=['POST'])
def add_url(): 
    '''
    Add new yarn or new pattern(s) to the database using a URL or a list of URLs
    '''
    try:
        # Get the JSON data from the request
        data = request.get_json()

        # Get the URL(s) from the data
        urls = data.get('url')  # Can be a single string or a list

        # Ensure URLs are provided
        if not urls:
            return jsonify({'message': 'URL(s) required'}), 400

        # Normalize `urls` to a list
        if isinstance(urls, str):
            urls = [urls]

        # Validate the type of data (yarn or pattern)
        type = data.get('type')
        if type not in ['yarn', 'pattern']:
            return jsonify({'message': 'Invalid type, must be "yarn" or "pattern"'}), 400

        # Initialize response data
        response_data = []

        for url in urls:
            # Check if the URL is valid
            if 'yarn.com' not in url and 'ravelry.com' not in url:
                response_data.append({'url': url, 'message': 'Invalid URL'})
                continue

            if type == 'yarn':
                # Get the yarn data from the URL
                yarn_data = get_yarn_data(url)

                # handle invalid data
                if yarn_data is None:
                    response_data.append({'url': url, 'message': 'Invalid URL or Try to Manually Add the Yarn'})
                    continue

                # Generate a new ID for the yarn
                yarn_data['yarn_id'] = find_next_id(yarn_collection, "yarn_id")

                # Check if the yarn already exists
                if yarn_collection.find_one({'yarn_name': yarn_data['yarn_name'], 'brand': yarn_data['brand'], 'yarn_weight': yarn_data['yarn_weight']}):
                    response_data.append({'url': url, 'message': 'Yarn already exists'})
                    continue
                
                # add created date
                yarn_data['created_date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                # Insert the yarn data into the database
                result = yarn_collection.insert_one(yarn_data)
                yarn_data['_id'] = str(result.inserted_id)
                response_data.append({
                    'url': url,
                    'message': 'Successfully imported yarn',
                    'new_yarn_id': yarn_data['yarn_id'],
                    'result': yarn_data
                })

            elif type == 'pattern':
                # Get the pattern data from the URL
                pattern_data = get_pattern_data(url)

                # Handle invalid data
                if pattern_data is None:
                    response_data.append({'url': url, 'message': 'Invalid URL or Try to Manually Add the Pattern'})
                    continue

                # Generate a new ID for the pattern
                new_pattern_id = find_next_id(pattern_collection, "pattern_id")
                pattern_data['pattern_id'] = new_pattern_id
                
                # Check if the pattern already exists
                if pattern_collection.find_one({'pattern_name': pattern_data['pattern_name'], 'author_name': pattern_data['author_name']}):
                    response_data.append({'url': url, 'message': 'Pattern already exists'})
                    continue

                # add created date
                pattern_data['created_date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                # Insert the pattern data into the database
                result = pattern_collection.insert_one(pattern_data)
                pattern_data['_id'] = str(result.inserted_id)
                response_data.append({
                    'url': url,
                    'message': 'Successfully imported pattern',
                    'new_pattern_id': new_pattern_id,
                    'result': pattern_data
                })

        return jsonify({
                    "message": "URL(s) processed",
                    "result": response_data
                }), 200

    except Exception as e:
        return jsonify({'message': f"An error occurred: {str(e)}"}), 500

    
#### 2. Add/Update your own inventory 
@app.route("/add/inventory_update", methods=['POST'])
def yarn_inventory_update():
    '''
    Add new yarn to inventory or update the quantity of the yarn in inventory
    '''
    try:
        # Get the JSON data from the request
        data = request.json
        
        # Extract the input data
        quantity = data.get('quantity')
        color_family = data.get('color_family', "")
        color_name = data.get('color_name')  # The color name from the yarn brand
        yarn_name = data.get('yarn_name')
        brand = data.get('brand')
        yarn_weight = data.get('yarn_weight')
        update_flag = data.get('update_flag', False)
        
        # Check if all the required fields are provided
        if quantity is None or not color_name or not yarn_name or not brand or not yarn_weight:
            return jsonify({'message': 'Please provide all the necessary variables (quantity, color_name, yarn_name, brand, yarn_weight)'}), 400
        
        # query to match substring: 
        query = {}
    
        if yarn_name:
            query["yarn_name"] = {"$regex": yarn_name, "$options": "i"}  # Case-insensitive substring matching

        if brand:
            query["brand"] = {"$regex": brand, "$options": "i"}  # Case-insensitive substring matching

        if yarn_weight:
            query["yarn_weight"] = {"$regex": yarn_weight, "$options": "i"}  # Case-insensitive substring matching

        yarn_collection_cnt = yarn_collection.count_documents(query)
        if yarn_collection_cnt == 0:
            return jsonify({"message": "No matching yarn found in the collection"}), 404
        elif yarn_collection_cnt > 1:
            return jsonify({"message": "Multiple matching yarns found. Please refine your search criteria."}), 400

        # Find yarn in yarn_collection
        yarn_info = yarn_collection.find_one(query, {'_id': 0})
        if not yarn_info:
            return jsonify({'message': 'Yarn is not in collection. Please update by providing yarn.com link to /add/url before creating inventory'}), 400

        # Calculate total length of yarn
        total_meter = yarn_info['yarn_length']['meter'] * quantity
        total_yard = yarn_info['yarn_length']['yard'] * quantity

        # Check if the yarn is already in the inventory
        existing_inventory = yarn_inventory_collection.find_one(
            {'yarn_name': yarn_info['yarn_name'], 'brand': yarn_info['brand'], 'yarn_weight': yarn_info['yarn_weight'], 'color_name': {"$regex": color_name, "$options": "i"} }
        )

        if not update_flag and existing_inventory:
            return jsonify({"message": "Yarn is already in inventory. To update the inventory, send 'update_flag': True in the request body."}), 400

        # Update the inventory if the update_flag is True and the yarn exists
        if update_flag and existing_inventory:
            modified_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if color_family:
                update_result = yarn_inventory_collection.update_one(
                    {'yarn_name': yarn_info['yarn_name'], 'brand': yarn_info['brand'], 'yarn_weight': yarn_info['yarn_weight'], 'color_name': {"$regex": color_name, "$options": "i"} },
                    {'$set': {
                        'quantity': quantity,
                        'total_meter': total_meter,
                        'total_yard': total_yard,
                        'color_family': color_family, 
                        'modified_date': modified_date
                    }}
                )
            else: 
                update_result = yarn_inventory_collection.update_one(
                    {'yarn_name': yarn_info['yarn_name'], 'brand': yarn_info['brand'], 'yarn_weight': yarn_info['yarn_weight'], 'color_name': {"$regex": color_name, "$options": "i"} },
                    {'$set': {
                        'quantity': quantity,
                        'total_meter': total_meter,
                        'total_yard': total_yard, 
                        'modified_date': modified_date
                    }}
                )
            updated_inventory = yarn_inventory_collection.find_one(
                {'yarn_name': yarn_info['yarn_name'], 'brand': yarn_info['brand'], 'yarn_weight': yarn_info['yarn_weight'], 'color_name': {"$regex": color_name, "$options": "i"} }
                , {'_id': 0}
            )
            return jsonify({'message': 'Inventory Updated', 'result': updated_inventory}), 200

        # Add new inventory if update_flag is False
        # Generate a new inventory ID
        last_inventory = yarn_inventory_collection.find_one(sort=[("inventory_id", -1)])  # Get the latest ID
        new_inventory_id = (last_inventory['inventory_id'] + 1) if last_inventory else 1  # Increment or start at 1

        # Add new inventory information
        yarn_info['inventory_id'] = new_inventory_id
        yarn_info['quantity'] = quantity
        yarn_info['total_meter'] = total_meter
        yarn_info['total_yard'] = total_yard
        if color_family:
            yarn_info['color_family'] = color_family
        yarn_info['color_name'] = color_name
        # add created date
        yarn_info['created_date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")


        # Insert the new inventory document into the inventory collection
        insert_result = yarn_inventory_collection.insert_one(yarn_info)
        yarn_info['_id'] = str(insert_result.inserted_id)  # Convert ObjectId to string

        return jsonify({'message': 'Inventory Added', 'result': yarn_info}), 201

    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

### 3a. Search yarn in yarn inventory 
## example call: http://127.0.0.1:5000/search/yarn_inventory?color_name=Concrete%20Tweed&yarn_name=Turin
@app.route("/search/yarn_inventory", methods=['GET'])
def search_yarn_inventory():
    """
    Search for a yarn in the inventory using any property as a query parameter.
    """
    try:

        raw_query_string = request.query_string
        # Get all query parameters from the request
        query_params = parse_query_params(raw_query_string)
        
        # Convert query parameters to the correct types if necessary
        # For example: Convert "quantity" to an integer
        if "inventory_id" in query_params:
            query_params["inventory_id"] = int(query_params["inventory_id"])
        if "yarn_id" in query_params:
            query_params["yarn_id"] = int(query_params["yarn_id"])
        if "quantity" in query_params:
            query_params["quantity"] = int(query_params["quantity"])
        if "total_meter" in query_params:
            query_params["total_meter"] = float(query_params["total_meter"])
        if "total_yard" in query_params:
            query_params["total_yard"] = float(query_params["total_yard"])
        if "inventory_id" in query_params:
            query_params["inventory_id"] = int(query_params["inventory_id"])
        
        # add regex to string column
        if "color_name" in query_params:
            query_params["color_name"] = {"$regex": query_params["color_name"], "$options": "i"}
        if "yarn_name" in query_params:
            query_params["yarn_name"] = {"$regex": query_params["yarn_name"], "$options": "i"}
        if "brand" in query_params:
            query_params["brand"] = {"$regex": query_params["brand"], "$options": "i"}
        if "yarn_weight" in query_params:
            query_params["yarn_weight"] = {"$regex": query_params["yarn_weight"], "$options": "i"}
        if "yarn_blend" in query_params:
            query_params["yarn_blend"] = {"$regex": query_params["yarn_blend"], "$options": "i"}
        # Search the database using the query parameters
        results = list(yarn_inventory_collection.find(query_params, {"_id": 0}))

        # If no results are found, return a message
        if not results:
            return jsonify({"message": "No yarns in inventory found matching the search criteria."}), 404

        # Return the results as JSON
        return jsonify({"message": "Yarns found in inventory", "results": results}), 200

    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500
    
### 3.b Search yarn in yarn collection
# Example API Call: http://127.0.0.1:5000/search/yarn_collection?net_weight.oz=1.76
@app.route("/search/yarn_collection", methods=['GET'])
def search_yarn_collection():
    """
    Search for a yarn in the collection using any property as a query parameter.
    """
    try:

        raw_query_string = request.query_string
        # Get all query parameters from the request
        query_params = parse_query_params(raw_query_string) 

        # Convert query parameters to the correct types if necessary
        if "yarn_id" in query_params:
            query_params["yarn_id"] = int(query_params["yarn_id"])
        if "yarn_length.meter" in query_params:
            query_params["yarn_length.meter"] = float(query_params["yarn_length.meter"])
        if "yarn_length.yard" in query_params:
            query_params["yarn_length.yard"] = float(query_params["yarn_length.yard"])
        if "net_weight.grams" in query_params:
            query_params["yarn_weight.grams"] = float(query_params["net_weight.grams"])
        if "net_weight.oz" in query_params:
            query_params["net_weight.oz"] = float(query_params["net_weight.oz"])
        
        # add regex to string column
        if "yarn_name" in query_params:
            query_params["yarn_name"] = {"$regex": query_params["yarn_name"], "$options": "i"}
        if "brand" in query_params:
            query_params["brand"] = {"$regex": query_params["brand"], "$options": "i"}
        if "yarn_weight" in query_params:
            query_params["yarn_weight"] = {"$regex": query_params["yarn_weight"], "$options": "i"}
        if "yarn_blend" in query_params:
            query_params["yarn_blend"] = {"$regex": query_params["yarn_blend"], "$options": "i"}
        # Search the database using the query parameters
        results = list(yarn_collection.find(query_params, {"_id": 0}))

        # If no results are found, return a message
        if not results:
            return jsonify({"message": "No yarns in collection found matching the search criteria."}), 404

        # Return the results as JSON
        return jsonify({"message": "Yarns found in collection", "results": results}), 200

    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500
    

### 4. Search pattern by author name, pattern name, category, yarn weight etc 
## Example API Call: http://127.0.0.1:5000/search/pattern?author_name=My%20Favourite%20Things&
@app.route("/search/pattern", methods=['GET'])
def search_pattern():
    try: 
        raw_query_string = request.query_string
        query_params= parse_query_params(raw_query_string)

        # Convert query parameters to the correct types if necessary
        if "pattern_id" in query_params:
            query_params["pattern_id"] = int(query_params["pattern_id"])
        if "min_yarn_requirement.yard" in query_params:
            query_params["min_yarn_requirement.yard"] = float(query_params["min_yarn_requirement.yard"])
        if "min_yarn_requirement.meter" in query_params:
            query_params["min_yarn_requirement.meter"] = float(query_params["min_yarn_requirement.meter"])
        if "max_yarn_requirement.yard" in query_params:
            query_params["max_yarn_requirement.yard"] = float(query_params["max_yarn_requirement.yard"])
        if "max_yarn_requirement.meter" in query_params:
            query_params["max_yarn_requirement.meter"] = float(query_params["max_yarn_requirement.meter"])

        # add regex to string column
        if "author_name" in query_params:
            query_params["author_name"] = {"$regex": query_params["author_name"], "$options": "i"}
        if "pattern_name" in query_params:
            query_params["pattern_name"] = {"$regex": query_params["pattern_name"], "$options": "i"}
        if "category.main" in query_params:
            query_params["category.main"] = {"$regex": query_params["category.main"], "$options": "i"}
        if "category.subcategory" in query_params:
            query_params["category.subcategory"] = {"$regex": query_params["category.subcategory"], "$options": "i"}
        if "yarn_weight" in query_params:
            query_params["yarn_weight"] = {"$regex": query_params["yarn_weight"], "$options": "i"}
        # Search the database using the query parameters
        results = list(pattern_collection.find(query_params, {"_id": 0}))

        # If no results are found, return a message
        if not results:
            return jsonify({"message": "No patterns in collection found matching the search criteria."}), 404

        # Return the results as JSON
        return jsonify({"message": "Patterns found in collection", "results": results}), 200
    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500
    
### 5. Delete pattern or yarn from the database
#### Example API Call: http:///127.0.0.1:5000/delete/pattern?author_name=John&pattern_name=CoolPattern
## 5a. Delete pattern based on author_name and pattern_name
@app.route('/delete/pattern', methods=['DELETE'])
def delete_pattern():
    """
    Delete a pattern based on author_name and pattern_name or pattern_id.
    both parameters must be provided in the request body, or an error is returned.
    """
    try:
        raw_query_string = request.query_string
        query_params = parse_query_params(raw_query_string)
        author_name = None
        pattern_name = None
        pattern_id = None
        # Get query parameters
        if 'author_name' in query_params:
            author_name = query_params.get('author_name')
        if 'pattern_name' in query_params: 
            pattern_name = query_params.get('pattern_name')
        if 'pattern_id' in query_params:
            pattern_id = query_params.get('pattern_id')

        if pattern_id:
            result = pattern_collection.delete_one({"pattern_id": int(pattern_id)})
            return jsonify({"message": "Yarn deleted successfully using pattern_id."}), 200
        
        elif author_name and pattern_name:
            query={}
            query["author_name"] = {"$regex": author_name, "$options": "i"}
            query["pattern_name"] = {"$regex": pattern_name, "$options": "i"}
            
            pattern_count = pattern_collection.count_documents(query)
            if pattern_count == 0:
                return jsonify({"message": "No matching pattern found in the collection"}), 404
            elif pattern_count > 1:
                return jsonify({"message": "Multiple matching patterns found. Please refine your criteria so we only delete 1 pattern at a time."}), 400
            
            matched_pattern = pattern_collection.find_one(query, {"_id": 0})
            
            result = pattern_collection.delete_one(query)
            

            return jsonify({"message": "Pattern deleted successfully using pattern information.",
                            "pattern_deleted": matched_pattern}), 200
        else:
            return jsonify({"message": "Please provide pattern_id or (author_name, pattern_name) to delete yarn from collection"}), 400
        
    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500


## 5b. delete yarn collection based on yarn_name, brand, yarn_weight
@app.route("/delete/yarn_collection", methods=['DELETE'])
def delete_yarn_col(): 
    try: 
        raw_query_string = request.query_string
        query_params = parse_query_params(raw_query_string)

        yarn_id = None
        yarn_name = None
        brand = None
        yarn_weight = None

        # Extract parameters from the request
        if 'yarn_id' in query_params:
            yarn_id = query_params.get('yarn_id')
        if 'yarn_name' in query_params:
            yarn_name = query_params.get('yarn_name')
        if 'brand' in query_params:
            brand = query_params.get('brand')
        if 'yarn_weight' in query_params:
            yarn_weight = query_params.get('yarn_weight')
        
        # delete based on yarn_id 
        if yarn_id:
            result = yarn_collection.delete_one({"yarn_id": int(yarn_id)})
            return jsonify({"message": "Yarn deleted successfully using yarn_id."}), 200
        # query to match substring:
        
        # delete based on yarn_name, brand, yarn_weight
        elif yarn_name and brand and yarn_weight:
            query = {}
            query["yarn_name"] = {"$regex": yarn_name, "$options": "i"}
            query["brand"] = {"$regex": brand, "$options": "i"}
            query["yarn_weight"] = {"$regex": yarn_weight, "$options": "i"}


            yarn_count = yarn_collection.count_documents(query)
            if yarn_count == 0:
                return jsonify({"message": "No matching yarn found in the collection"}), 404
            elif yarn_count > 1:
                return jsonify({"message": "Multiple matching yarns found. Please refine your criteria so we only delete 1 pattern at a time."}), 400
            
            matched_yarn = yarn_collection.find_one(query, {"_id": 0})

            result = yarn_collection.delete_one(query)
        
            return jsonify({"message": "Yarn deleted successfully using yarn information.", 
                            "deleted_yarn": matched_yarn}), 200
        else:
            return jsonify({"message": "Please provide yarn_id or (yarn_name, brand, yarn_weight) to delete yarn from collection"}), 400
        
    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

### 5c Delete yarn from inventory based on yarn_name, brand, yarn_weight, color_name or inventory_id
@app.route('/delete/yarn_inventory', methods=['DELETE'])
def delete_yarn_inventory():
    """
    Delete a yarn based on yarn_name, brand, yarn_weight and color_name or inventory_id.
    all parameters must be provided in the request body, or an error is returned.
    """
    try:
        raw_query_string = request.query_string
        query_params = parse_query_params(raw_query_string)
        # init params: 
        yarn_name = None
        brand = None
        yarn_weight = None
        color_name = None
        inventory_id = None

        # get parameters: 
        if 'yarn_name' in query_params:
            yarn_name = query_params.get('yarn_name')
        if 'brand' in query_params:
            brand = query_params.get('brand')
        if 'yarn_weight' in query_params:
            yarn_weight = query_params.get('yarn_weight')
        if 'color_name' in query_params:
            color_name = query_params.get('color_name')
        if 'inventory_id' in query_params:
            inventory_id = query_params.get('inventory_id')

        # delete based on inventory_id 
        if inventory_id:
            result = yarn_inventory_collection.delete_one({"inventory_id": int(inventory_id)})
            return jsonify({"message": "Yarn deleted successfully using inventory_id."}), 200
        # delete based on yarn_name, brand, yarn_weight, and color_name
        elif yarn_name and brand and yarn_weight and color_name:
            # match substring 
            query = {}
            query["yarn_name"] = {"$regex": yarn_name, "$options": "i"}
            query["brand"] = {"$regex": brand, "$options": "i"}
            query["yarn_weight"] = {"$regex": yarn_weight, "$options": "i"}
            query["color_name"] = {"$regex": color_name, "$options": "i"}

            yarn_count = yarn_inventory_collection.count_documents(query)
            if yarn_count == 0:
                return jsonify({"message": "No matching yarn found in the collection"}), 404
            elif yarn_count > 1:
                return jsonify({"message": "Multiple matching yarns found. Please refine your criteria so we only delete 1 pattern at a time."}), 400
            
            matched_yarn = yarn_inventory_collection.find_one(query, {"_id": 0})

            result = yarn_inventory_collection.delete_one(query)   
            return jsonify({"message": "Yarn deleted successfully using yarn information.", 
                            "deleted_inventory": matched_yarn}), 200
        else:
            return jsonify({"message": "Please provide inventory_id or (yarn_name, brand, yarn_weight,color_name) to delete yarn from collection"}), 400
        
    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

### 6. Find inventory yarn or yarn collection given the pattern and author name.
@app.route('/find_yarn_for_proj', methods=['GET'])
def find_yarn_for_proj(): 
    """
    Find suitable yarn in the inventory for a given pattern and author.
    """
    try:
        raw_query_string = request.query_string
        query_params = parse_query_params(raw_query_string)
        
        # Get query parameters
        if "author_name" in query_params:
            query_params["author_name"] = {"$regex": query_params["author_name"], "$options": "i"}
        if "pattern_name" in query_params:
            query_params["pattern_name"] = {"$regex": query_params["pattern_name"], "$options": "i"}
        if "category.main" in query_params:
            query_params["category.main"] = {"$regex": query_params["category.main"], "$options": "i"}
        if "category.subcategory" in query_params:
            query_params["category.subcategory"] = {"$regex": query_params["category.subcategory"], "$options": "i"}
        if "yarn_weight" in query_params:
            query_params["yarn_weight"] = {"$regex": query_params["yarn_weight"], "$options": "i"}

        results = list(pattern_collection.find(query_params, {"_id": 0}))

        # make sure there is only 1 pattern
        pattern_count = pattern_collection.count_documents(query_params)

        if pattern_count == 0:
            return jsonify({"message": f"No matching pattern found in the collection"}), 404
        elif pattern_count > 1:
            return jsonify({"message": "Multiple matching patterns found. Please refine your search criteria.", 
                            "result": list(pattern_collection.find(query_params, {"_id":0}))}), 400
        
        # find for the pattern requirement
        pattern = pattern_collection.find_one(query_params, {"_id":0})

        # Calculate yarn requirement
        min_yarn_requirement_meter = pattern['min_yarn_requirement']['meter']
        max_yarn_requirement_meter = pattern['max_yarn_requirement']['meter']
        yarn_requirement = (min_yarn_requirement_meter + max_yarn_requirement_meter) / 2  # Assume medium size

        # Normalize yarn weight
        pattern_yarn_weight = pattern['yarn_weight'].lower()

        # Define yarn weight relationships for doubling
        doubling_map = {
            "lace": ["thread"], 
            "sock": ["lace"],
            'fingering': ['lace'], 
            "sport": ['sock'], 
            "dk": ['fingering', 'sock'], 
            'worsted': ['sport', 'dk'], 
            'aran': ['dk'], 
            'bulky': ['worsted'], 
            'chunky':['worsted'], 
            'super bulky': ['aran'],
            'jumbo': ['bulky']
        }
        # all potential yarn weights, including doubled options
        potential_weights = doubling_map.get(pattern_yarn_weight, [])
        potential_weights.append(pattern_yarn_weight)  # Include the exact match

        regex_potential_weights = [
                {"$regex": f"^{weight}$", "$options": "i"} for weight in potential_weights
            ]
        matching_yarns_old = list(
            yarn_inventory_collection.find(
                {
                    "yarn_weight": {"$in": potential_weights},
                    "$expr": {
                        "$or": [
                            {"$and": [
                                {"$eq": ["$yarn_weight", pattern_yarn_weight]},
                                {"$gte": ["$total_meter", yarn_requirement]}
                            ]},
                            {"$and": [
                                {"$ne": ["$yarn_weight", pattern_yarn_weight]},
                                {"$gte": ["$total_meter", 2 * yarn_requirement]}
                            ]}
                        ]
                    }
                },
                {"_id": 0}
            )
        )
        matching_yarns = []

        # Loop through each weight in potential_weights
        for weight in potential_weights:
            # Case-insensitive regex to match the weight
            regex_query = {"$regex": f"^{weight}$", "$options": "i"}
            
            # Match condition based on whether the weight matches pattern_yarn_weight
            if weight == pattern_yarn_weight:
                result = list(
                    yarn_inventory_collection.find(
                        {
                            "yarn_weight": regex_query,
                            "$expr": {"$gte": ["$total_meter", yarn_requirement]}
                        },
                        {"_id": 0}  # Exclude the _id field
                    )
                )
        
            else:
                result = list(
                    yarn_inventory_collection.find(
                        {
                            "yarn_weight": regex_query,
                            "$expr": {"$gte": ["$total_meter", 2 * yarn_requirement]}
                        },
                        {"_id": 0}  # Exclude the _id field
                    )
                )
                
            # Append results to the list
            matching_yarns.extend(result)
        
        if len(matching_yarns) == 0:
            return jsonify(
                {"message": "No matching yarn weight or enough yarn found in the inventory"}
            ), 404
        
        return jsonify(
            {
                "message": "Matching yarn(s) found in the inventory",
                "yarn_requirement": potential_weights,
                "matching_yarns": matching_yarns
            }
        ), 200
    
    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

### 7. Input yarn name, brand and yarn weight, return the pattern that can be made with the yarn.
# This is useful as you want to buy new yarn and want to check if there is a pattern suitable for that yarn
@app.route('/find_pattern_given_yarn', methods=['POST'])
def find_pattern_given_yarn():
    try:
        data = request.get_json()
        
        # init params 
        yarn_name = None
        brand = None
        yarn_weight = None
        url = None

        # paramters: 
        if 'yarn_name' in data:
            yarn_name = data.get('yarn_name')
        if 'brand' in data:
            brand = data.get('brand')
        if 'yarn_weight' in data:
            yarn_weight = data.get('yarn_weight')
        if 'url' in data:
            url = data.get('url')

        message=None
        # need to be (yarn_name, brand, yarn_weight) or url
        if not (yarn_name and brand and yarn_weight) and not url:
            return jsonify({"message": "Please provide yarn_name, brand, yarn_weight or url to find pattern"}), 400
        
        # if url is provided, get yarn data
        if url:
            # Check if the URL is valid
            if 'yarn.com' not in url:
                    return jsonify({'url': url, 'message': 'Invalid URL'}), 400

            # Get the yarn data from the URL
            yarn_data = get_yarn_data(url)

            # Generate a new ID for the yarn
            yarn_data['yarn_id'] = find_next_id(yarn_collection, "yarn_id")

            # check yarn_collection
            yarn_info = yarn_collection.find_one({'yarn_name': yarn_data['yarn_name'], 'brand': yarn_data['brand'], 'yarn_weight': yarn_data['yarn_weight']}, {'_id': 0})
            
            # insert to yarn_collection if not in yarn_collection
            if not yarn_info:
                yarn_data['yarn_id'] = find_next_id(yarn_collection, 'yarn_id')
                result = yarn_collection.insert_one(yarn_data)
                yarn_info = yarn_collection.find_one({'yarn_id': yarn_data['yarn_id']}, {'_id': 0})
                message = "yarn from url added to yarn_collection"
            else:   
                message= "yarn is already in yarn_collection"
        else: 
            query = {}
            query["yarn_name"] = {"$regex": yarn_name, "$options": "i"}
            query["brand"] = {"$regex": brand, "$options": "i"}
            query["yarn_weight"] = {"$regex": yarn_weight, "$options": "i"}
            # check yarn exists in yarn_collection
            yarn_info = yarn_collection.find_one(query, {'_id': 0})
            if not yarn_info:
                return jsonify({'message': 'Yarn is not in collection. Please provide an url from yarn.com link'}), 400
            message = "yarn is already in yarn_collection"

        # get yarn weight for pattern search
        yarn_weight = yarn_info['yarn_weight']
        pattern_query={}
        pattern_query['yarn_weight'] = {"$regex": yarn_weight, "$options": "i"}
        # find pattern 
        matched_patterns = list(pattern_collection.find(pattern_query, {'_id': 0}))
        
        # check if yarn is in inventory
        yarn_inventory_cnt = yarn_inventory_collection.count_documents({'yarn_name': yarn_info['yarn_name'], 'brand': yarn_info['brand'], 'yarn_weight': yarn_info['yarn_weight']})
        if yarn_inventory_cnt == 0:
            yarn_inventory_message = "Yarn is not in inventory"
        else: 
            yarn_inventory_message = "Yarn is in inventory"

        if not matched_patterns:
            return jsonify({'message': 'No matching pattern found for the yarn',
                            "yarn_inventory": yarn_inventory_message,
                            "yarn_collection":message}), 404
        
        return jsonify({'message': 'Matching pattern found for the yarn',
                        "yarn_collection": message,
                        "yarn_inventory": yarn_inventory_message, 
                        'pattern': matched_patterns}), 200
    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500
    
### 8. Save all current collection into json file 
@app.route('/save_all_collections_to_json', methods=['GET'])
def save_all_collection_to_json():
    """
    Save the current status of all collections in the database to JSON files.
    Each collection will be saved to a separate JSON file.
    """
    try:

        # Get the list of all collections in the database
        collections = db.list_collection_names()

        saved_files = []  # To track saved file names

        for collection_name in collections:
            # Fetch all documents from the collection
            documents = list(db[collection_name].find({}))
            
            # Convert MongoDB ObjectId to string for JSON serialization
            for doc in documents:
                if "_id" in doc:
                    doc["_id"] = str(doc["_id"])
            
            # Save the collection to a JSON file
            file_path = os.path.join(output_dir, f"{collection_name}.json")
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(documents, f, ensure_ascii=False, indent=4)

            saved_files.append(file_path)

        return jsonify({"message": "Collections saved successfully", "files": saved_files}), 200

    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500