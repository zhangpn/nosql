## README: Knitventory: MongoDB Integration and Web API Development for your knitting resources

### **Project Overview**
This project leverages a NoSQL database to create a personalized platform for managing knitting resources, specifically yarns and knitting patterns. By providing a more organized way to manage, an retrieve information related your yarn and pattern collection, the platform helps streamline project planning and makes it easier to find compatible materials for new or existing projects. You can now search your inventory for suitable yarns before making additional purchases, ultimately helping you manage your stash effectively and avoid unnecessary overspending on yarn.

---
### **Objectives**
- **MongoDB and Python Integration:**  
  - Use PyMongo to perform database operations such as insertion, querying, and updating from Python.

- **Web API Development:**  
  - Develop RESTful APIs using Flask to interact with the MongoDB database and manage endpoints effectively.

---

### **Requirements**
#### **Applications and Libraries:**
- **Applications:**  
  - Docker  
  - Postman  

- **Libraries:**  
  Install necessary libraries with the following command:

```bash
  pip install python pandas flask pymongo
```
---
### Setting Up the Docker Container
1. Ensure your working directory is correctly set to the location of the `docker-compose.yml` file.
2. Verify that volumes in the Docker configuration match the path to your application folder.
3. Launch the containers with the following command:
```bash
docker-compose up
```
--- 
### Importing Data into MongoDB
The extracted JSON files are:
- `inventory.json`
- `pattern.json`
- `yarn.json`

You can import with 2 different method 

#### A. Through MongoDB Shell: 

  - Start by accessing the MongoDB shell through Docker:

```bash 
docker-compose exec -it mongodb sh
```
  - Use the following commands to import the JSON data into the careerhub database:


```bash 
mongoimport --db knittinghub --collection pattern --file /ds5760/mongo/data/pattern_db.json --jsonArray
mongoimport --db knittinghub --collection yarn --file /ds5760/mongo/data/yarn_db.json --jsonArray
mongoimport --db knittinghub --collection inventory --file /ds5760/mongo/data/inventory.json --jsonArray

```

#### B. Through API 
  - Start by running `python run-app.py` in your terminal
  - Open POSTMAN with GET method, run `http://127.0.0.1:5000/import/json?collection_name=yarn`
    - `collection_name` can be "yarn", "inventory" or "pattern"
---

### Schema Design

The project uses three MongoDB collections: yarn, patterns, and inventory. These collections were designed to organize data efficiently and cater to the needs of users managing their knitting resources. 

#### 1. **Yarn Collection**
The `yarn` collection stores detailed information about different types of yarn, including their composition, weight, length, and recommended needle sizes. This collection is essential for users managing their yarn inventory and searching for compatible yarns for specific knitting patterns.
- **Purpose**: Useful for users to maintain a database of all available yarn information with detailed specifications. The yarns in this collection may or may not be part of the user's inventory.
- **Source**: Data in the `yarn` collection is scraped from [yarn.com](https://www.yarn.com).
- Fields: 
```json
- yarn_id
- url
- brand
- yarn_name
- net_weight
  - gram
  - oz
- yarn_blend
- yarn_length
  - yard
  - meter
- suggested_needles
  - US size
  - international_size_mm
- care
- tension_gauge
- yarn_weight
```

#### 2. `pattern` Collection
The `pattern` collection contains information about knitting patterns that the users currently owned, including the pattern name, author, category, and recommended yarns. 
- **Purpose**: To store/ manage their purchased knitting patterns. And it also allows them to explore and ensure compatibility with their yarn inventory.
- **Source**: Data in the `pattern` collection is scraped from [ravelry.com](https://www.ravelry.com). Ravelry is one of the world largest knitting patterns store
- **Fields**: 
```json 
- url
- pattern_name
- author_name
- category
  - main
  - subcategory
- suggested_yarn
- yarn_weight
- min_yarn_requirement
  - yard
  - meter
- max_yarn_requirement
  - yard
  - meter
- gauge
- needle_size
- hook_size
- size
- pattern_properties
- pattern_id
- created_date
```


#### 3.  Inventory Collection
The `inventory` collection combines data from the yarn collection with additional fields specific to the user's inventory. It tracks quantities, color information, and total length, helping users manage their yarn stock effectively.

- **Purpose**: Allows users to maintain a real-time inventory of yarn with correct yarn specificity while having details on available quantities and colors for easy project planning.
- **Source**: Personal input data through either providing your own `inventory.json` and imported the file or manually updating using CALL `/add/inventory_update` with POSTMAN. More detailed on how to use will be below
- **Fields**: 
```json 
- similar to yarn collection fileds
- quantity
- total_meter
- total_yard
- color_family
- color_name

```

### Building the Web API with Flask
1. Run your Flask application:
```bash 
python run-app.py
```
2. Use POSTMAN to test the API endpoints for CRUD operations

---
## API Endpoints Documentation

This section provides an overview of the application functions, their purpose, required inputs, and how to make requests using Postman. Each function corresponds to a specific endpoint that facilitates interaction with the CareerHub API.
**Notes**: 
- the URL for Postman can be either `http://127.0.0.1:5000/` or `http://localhost:5000/`
- Some of the example I listed down below might be an exact match to datapoint

### 1. **Function: `get_initial_response()`**
- **Definition and Purpose:**  
This function defines the **homepage** of the API and serves as a **welcome message** to users when they access the root URL (`/`). It provides basic information about the API version and its status.

- **Required Input:**  None. This endpoint does not require any input.

- **Postman Request Example:**  
  **Method:** `GET`  
  **URL:** `http://127.0.0.1:5000/`


### 2. **Function: `import_json_to_mongodb()`**
- **Definition and Purpose:**  
This function imports a JSON file into a specified MongoDB collection (`yarn`, `pattern`, or `inventory`). It validates the collection, compares document counts, and updates or replaces the collection as necessary to ensure data consistency.

- **Required Input:**  
  - **Query Parameters**:
    - `collection_name` (string): The name of the collection to be updated (`yarn`, `pattern`, or `inventory`).

- **Expected Output:**  
  - **Success**:
    - `201`: Inserted all documents into a new collection.
    - `200`: Replaced or validated that the collection is up to date.
  - **Error**:
    - `400`: Invalid collection name, missing parameters, or JSON array issues.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `GET`  
  **URL:** `http://127.0.0.1:5000/import/json?collection_name=yarn`

### 3. **Function: `add_url()`**
- **Definition and Purpose:**  
This function allows users to add new yarn or pattern information to the database by providing one or multiple URLs. It processes the URLs, validates the data type (yarn or pattern), and imports the information into the appropriate collection.

- **Required Input:**  
  - **Body (JSON)**:
    - `url` (string or list of strings): URL(s) pointing to the yarn or pattern information. URL needs to come from `yarn.com` or `ravelry.com`. Within each list, it can only be URL from all yarn.com or all ravelry.com
    - `type` (string): The type of data to add (`yarn` or `pattern`).

- **Expected Output:**  
  - **Success**:
    - `200`: URLs processed successfully with details of imported or skipped items.
  - **Error**:
    - `400`: Missing or invalid parameters (e.g., no URL, invalid type).
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `POST`  
  **URL:** `http://127.0.0.1:5000/add/url`  
  **Body (JSON):**  

  ```json
  {
    "url": [
      "https://www.yarn.com/product-page/example-yarn",
    ],
    "type": "yarn"
  }
```   
or
```json
  {
    "url": 
      ["https://www.ravelry.com/patterns/library/example-pattern"]
    "type": "pattern"
  }
```
### 4. **Function `yarn_inventory_update`**
- **Definition and Purpose:**  
This function allows users to add a new yarn entry to their inventory or update the quantity and details of an existing yarn in the inventory. It ensures that the yarn exists in the main collection before adding or updating inventory information.
We need to include color_name in the inventory because for a specific yarn, we can have multiple colors.
- **Required Input:**  
  - **Body (JSON):**
    - `quantity` (int): The number of skeins of yarn to add or update.
    - `color_family` (string, optional): The general color classification of the yarn (e.g., Blue).
    - `color_name` (string): The specific color name of the yarn.
    - `yarn_name` (string): The name of the yarn.
    - `brand` (string): The brand of the yarn.
    - `yarn_weight` (string): The weight classification of the yarn (e.g., Bulky, Sport).
    - `update_flag` (boolean, optional): Set to `True` to update an existing inventory entry.

- **Expected Output:**  
  - **Success**:
    - `201`: New inventory item added successfully, with the details of the added item.
    - `200`: Existing inventory item updated successfully, with the updated details.
  - **Error**:
    - `400`: Missing required fields, invalid data, or an attempt to update inventory without setting `update_flag` to `True`.
    - `404`: No matching yarn found in the main collection.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `POST`  
  **URL:** `http://127.0.0.1:5000/add/inventory_update`  
  **Body (JSON):**  
  ```json
  {
    "quantity": 5,
    "color_family": "Blue",
    "color_name": "Turquoise",
    "yarn_name": "Turin",
    "brand": "String",
    "yarn_weight": "Bulky",
    "update_flag": true
  }

### 5. **Function `search_yarn_inventory`**
- **Definition and Purpose:**  
This function allows users to search for yarn in the inventory using various properties as query parameters. It supports partial and case-insensitive matching for string fields and exact matching for numeric fields.
Similarly, I want to search with `color_name` because I can own different colors of the same yarn.
- **Required Input:**  
  - **Query Parameters (optional):**
    - `color_name` (string): The specific color name (supports partial and case-insensitive matching).
    - `yarn_name` (string): The name of the yarn (supports partial and case-insensitive matching).
    - `brand` (string): The brand of the yarn (supports partial and case-insensitive matching).
    - `yarn_blend` (string): The fiber composition of yarn(can be cotton, linen, merino, wool)
    - `yarn_weight` (string): The weight classification of the yarn (e.g., Bulky, Sport).
    - `quantity` (int): The quantity of yarn in the inventory.
    - `total_meter` (float): The total meter length of the yarn.
    - `total_yard` (float): The total yard length of the yarn.
    - `inventory_id` (int): The unique inventory identifier.
    - `yarn_id` (int): The unique yarn identifier.

- **Expected Output:**  
  - **Success**:
    - `200`: Matching yarn(s) found, with a list of results returned.
  - **Error**:
    - `404`: No matching yarn found in the inventory.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `GET`  
  **URL:** `http://127.0.0.1:5000/search/yarn_inventory?color_name=Concrete%20Tweed&yarn_name=turin&yarn_blend=wool`  

### 6. **Function `search_yarn_collection`**
- **Definition and Purpose:**  
This function allows users to search for yarn in the main yarn collection using any property as a query parameter. It supports partial and case-insensitive matching for string fields and exact matching for numeric fields, enabling detailed and flexible searches.

- **Required Input:**  
  - **Query Parameters (optional):** You can use all the fields from yarn collection but here are some recommended parameters
    - `yarn_name` (string): The name of the yarn (supports partial and case-insensitive matching).
    - `brand` (string): The brand of the yarn (supports partial and case-insensitive matching).
    - `yarn_weight` (string): The weight classification of the yarn (e.g., Bulky, Sport).
    - `yarn_blend` (string): The blend composition of the yarn (supports partial and case-insensitive matching).
    - `yarn_id` (int): The unique identifier of the yarn.
    - `yarn_length.meter` (float): The length of the yarn in meters.
    - `yarn_length.yard` (float): The length of the yarn in yards.
    - `net_weight.grams` (float): The weight of the yarn in grams.
    - `net_weight.oz` (float): The weight of the yarn in ounces.

- **Expected Output:**  
  - **Success**:
    - `200`: Matching yarn(s) found in the collection, with a list of results returned.
  - **Error**:
    - `404`: No matching yarn found in the collection.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `GET`  
  **URL:** `http://127.0.0.1:5000/search/yarn_collection?net_weight.oz=1.76`  

### 7. **Function `search_pattern`**: 
- **Definition and Purpose:**  
This function allows users to search for knitting patterns in the collection using various properties as query parameters. It supports partial and case-insensitive matching for string fields and exact matching for numeric fields

- **Required Input:**  
  - **Query Parameters (optional):** You can search with all the properties from `pattern` collection but here are some of the recommended fields 
    - `pattern_id` (int): The unique identifier of the pattern.
    - `author_name` (string): The name of the pattern's author (supports partial and case-insensitive matching).
    - `pattern_name` (string): The name of the pattern (supports partial and case-insensitive matching).
    - `category.main` (string): The main category of the pattern (e.g., Sweater).
    - `category.subcategory` (string): The subcategory of the pattern (e.g., Pullover).
    - `yarn_weight` (string): The weight classification of the yarn required for the pattern.
    - `min_yarn_requirement.yard` (float): The minimum yarn requirement in yards.
    - `min_yarn_requirement.meter` (float): The minimum yarn requirement in meters.
    - `max_yarn_requirement.yard` (float): The maximum yarn requirement in yards.
    - `max_yarn_requirement.meter` (float): The maximum yarn requirement in meters.

- **Expected Output:**  
  - **Success**:
    - `200`: Matching pattern(s) found in the collection, with a list of results returned.
  - **Error**:
    - `404`: No matching patterns found in the collection.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `GET`  
  **URL:** `http://127.0.0.1:5000/search/pattern?pattern_name=Cambersands%20Sweater&yarn_weight=Sport`  

### 8.  **Function `delete_pattern`**:
- **Definition and Purpose:**  
This function deletes a pattern from the collection using either the `pattern_id` or a combination of `author_name` and `pattern_name`. It ensures that only one pattern is deleted at a time

- **Required Input:**  
  - **Query Parameters** (one of the following is required):
    - `pattern_id` (int): The unique identifier of the pattern.
    - `author_name` (string) and `pattern_name` (string): The author's name and the pattern's name (supports partial and case-insensitive matching).

- **Expected Output:**  
  - **Success**:
    - `200`: Pattern deleted successfully, with details of the deleted pattern (if applicable).
  - **Error**:
    - `400`: Missing required parameters or multiple matches found.
    - `404`: No matching pattern found in the collection.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `DELETE`  
  **URL:** `http://127.0.0.1:5000/delete/pattern?pattern_id=4`  

  **OR**  

  **Method:** `DELETE`  
  **URL:** `http://127.0.0.1:5000/delete/pattern?author_name=Cheryl%20Mokhtari&pattern_name=Cambersands%20Sweater`  

### 9.  **Function `delete_yarn_col` **: 
- **Definition and Purpose:**  
This function deletes a yarn from the main yarn collection using either the `yarn_id` or a combination of `yarn_name`, `brand`, and `yarn_weight`. It ensures only one yarn entry is deleted per request.

- **Required Input:**  
  - **Query Parameters** (one of the following is required):
    - `yarn_id` (int): The unique identifier of the yarn.
    - `yarn_name` (string), `brand` (string), and `yarn_weight` (string): The name, brand, and weight classification of the yarn (supports partial and case-insensitive matching).

- **Expected Output:**  
  - **Success**:
    - `200`: Yarn deleted successfully, with details of the deleted yarn.
  - **Error**:
    - `400`: Missing required parameters or multiple matches found.
    - `404`: No matching yarn found in the collection.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `DELETE`  
  **URL:** `http://127.0.0.1:5000/delete/yarn_collection?yarn_name=huntington&brand=valley&yarn_weight=dk`  

###  **10. Function `delete_yarn_inventory` **: 
- **Definition and Purpose:**  
This function deletes a yarn from the inventory collection using either the `inventory_id` or a combination of `yarn_name`, `brand`, `yarn_weight`, and `color_name`. It ensures only one inventory entry is deleted per request. It is required to have `color_name` because I can own different colors of the same yarn. This allows for more specific deletion.

- **Required Input:**  
  - **Query Parameters** (one of the following is required):
    - `inventory_id` (int): The unique identifier of the inventory entry.
    - `yarn_name` (string), `brand` (string), `yarn_weight` (string), and `color_name` (string): The name, brand, weight classification, and specific color of the yarn (supports partial and case-insensitive matching).

- **Expected Output:**  
  - **Success**:
    - `200`: Yarn deleted successfully, with details of the deleted inventory entry.
  - **Error**:
    - `400`: Missing required parameters or multiple matches found.
    - `404`: No matching yarn found in the inventory.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `DELETE`  
  **URL:** `http://127.0.0.1:5000/delete/yarn_inventory?inventory_id=3`  

  **OR**  

  **Method:** `DELETE`  
  **URL:** `http://127.0.0.1:5000/delete/yarn_inventory?yarn_name=Turin&brand=String&yarn_weight=Bulky&color_name=turquoise`  

### 11. **Function find_yarn_for_proj**: 
- **Definition and Purpose:**  
This function identifies suitable yarn in the inventory for a specific knitting pattern based on its requirements, including yarn weight and total yardage. It also accounts for "held double" yarns, where two strands of lighter-weight yarns can substitute for the required weight.

- **Required Input:**  
  - **Query Parameters**:
    - `author_name` (string): The name of the pattern's author (supports partial and case-insensitive matching).
    - `pattern_name` (string): The name of the pattern (supports partial and case-insensitive matching).
    - `category.main` (string): The main category of the pattern (e.g., Sweater).
    - `category.subcategory` (string): The subcategory of the pattern (e.g., Pullover).
    - `yarn_weight` (string): The required yarn weight for the pattern.

- **Expected Output:**  
  - **Success**:
    - `200`: Matching yarn(s) found in the inventory, including details of potential yarns and their required yardage.
  - **Error**:
    - `400`: Multiple matching patterns found, requiring more specific criteria.
    - `404`: No matching patterns or yarns found that meet the requirements.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `GET`  
  **URL:** `http://127.0.0.1:5000/find_yarn_for_proj?author_name=Cheryl%20Mokhtari&pattern_name=Cambersands%20Sweater&yarn_weight=DK`  

- **Additional Notes:**  
  - If the required yarn weight is not available, the function considers lighter-weight yarns that can be held double to achieve the same weight (e.g., holding two strands of sock yarn to match DK weight).
  - Yarn suitability is determined by the total yardage available in the inventory and whether it meets or exceeds the pattern's requirements.

### 12. **Function `find_pattern_given_yarn`**
- **Definition and Purpose:**  
This function finds knitting patterns that match the provided yarn based on its weight. It is useful when you have a specific yarn you want to use and need to find patterns you already own that are compatible. Additionally, it checks if the specified yarn is in the inventory and provides relevant information about its status in the collection and inventory.

- **Required Input:**  
  - **Body (JSON):**
    - `yarn_name` (string, optional): The name of the yarn.
    - `brand` (string, optional): The brand of the yarn.
    - `yarn_weight` (string, optional): The weight classification of the yarn (e.g., Bulky, DK).
    - `url` (string, optional): A valid URL from `yarn.com` to fetch the yarn's details.

- **Expected Output:**  
  - **Success**:
    - `200`: Matching patterns found for the yarn, with details of the yarn's status in the collection and inventory.
  - **Error**:
    - `400`: Missing required inputs or invalid URL.
    - `404`: No patterns found that match the yarn's weight.
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `POST`  
  **URL:** `http://127.0.0.1:5000/find_pattern_given_yarn`  
  **Body (JSON):**  
  ```json
  {
    "yarn_name": "Turin",
    "brand": "String",
    "yarn_weight": "Bulky"
  }
```
OR 
```json
{
  "url": "https://www.yarn.com/product-page/example-yarn"
}
```

### 13. **Function `save_all_collections_to`**: 
- **Definition and Purpose:**  
This function saves the current status of all MongoDB collections to separate JSON files. Each collection is exported as a JSON file for backup or further processing.

- **Required Input:**  
  - None. This endpoint does not require any input.

- **Expected Output:**  
  - **Success**:
    - `200`: Collections successfully saved to JSON files, with a list of file paths returned.
  - **Error**:
    - `500`: Internal server error.

- **Postman Request Example:**  
  **Method:** `GET`  
  **URL:** `http://127.0.0.1:5000/save_all_collection_to_json`  

- **Additional Notes:**  
  - Each collection is saved as a separate JSON file in the designated output directory.
  - MongoDB `ObjectId` fields are converted to strings for JSON serialization.
  - Useful for creating backups or exporting data for analysis or migration.


## Acknowledgement 
I want to acknowledge the use of ChatGPT for assisting me writing up the documentation and debugging my code.



