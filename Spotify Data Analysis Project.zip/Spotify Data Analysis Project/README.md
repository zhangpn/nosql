
# Spotify Data Analysis Project

## Summary

This project processes Spotify listening history to generate insights, leveraging MongoDB for data storage and Python for data cleaning, querying, and analysis. The key functionalities include:

1. **Data Cleaning:** Combines and processes raw Spotify listening data into clean, structured datasets.
2. **Data Querying:** Uses MongoDB to store and analyze structured data, including track popularity, listening patterns, and feature clustering.
3. **Machine Learning:** Applies clustering to group tracks by audio features, visualizes results, and updates MongoDB with cluster IDs.

---

## Setup Instructions

### Prerequisites

1. Install **Docker** to run MongoDB.
2. Install **Python 3.7+** and the required Python libraries:
   ```bash
   pip install pandas numpy sklearn pymongo matplotlib
   ```

### Steps to Set Up

1. **Set up MongoDB:**
   - Run the following command in the directory with `docker-compose.yml`:
     ```bash
     docker-compose up -d
     ```
     This starts a MongoDB container accessible on `localhost:27017`.

2. **Prepare Data:**
   - Place your Spotify data files (e.g., `track_history.csv`, `audio_features.json`) in the `data/` directory.

3. **Run the Notebooks:**
   - Open the Jupyter Notebooks (`data_clean.ipynb`, `query.ipynb`, `ML.ipynb`) using Jupyter Notebook or Jupyter Lab:
     ```bash
     jupyter notebook
     ```
   - **Data Cleaning:** Execute `data_clean.ipynb` to combine, clean, and prepare Spotify data.
   - **Data Querying:** Run `query.ipynb` to load data into MongoDB and perform analyses like:
     - Top 10 most played songs
     - Day vs. night listening patterns
     - Popularity trends
   - **Machine Learning:** Use `ML.ipynb` to:
     - Cluster tracks by audio features.
     - Visualize clustering with PCA.
     - Update MongoDB with cluster IDs for each track.

---

## Key Features

- **Insights into Listening Habits:**
  - Analyze top tracks, artists, and albums.
  - Compare listening trends during different times of the day.
- **Clustering of Tracks:**
  - Group similar tracks based on audio features like danceability, energy, and tempo.
  - Visualize clusters using dimensionality reduction (PCA).
- **MongoDB Integration:**
  - Store and query processed data for further analysis.
  - Update cluster labels for tracks directly in MongoDB.

---

## Notes

- Update the `volumes` path in `docker-compose.yml` to match your local directory structure.
- Ensure your environment variables (`SPOTIFY_CLIENT_ID`, `SPOTIFY_CLIENT_SECRET`) are correctly set for API calls if needed.
- Sample outputs and visualizations are included in the notebooks.
