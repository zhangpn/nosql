# Movie Finder

Movie Finder is a web application designed to provide users with an easy-to-use interface for searching and exploring IMDb movie data. 

## Features
- Search for movies by applying multiple filters simultaneously.
- View detailed information about a movie, including title, directors, writers, genres, and ratings.
- Refresh the movie database from IMDb Non-Commercial Datasets directly from the application interface.

## Queries Supported
You can search for movies using the following filters:
- **Title**: Search for movies by name.
- **Year**: Specify a range using "After Year" and "Before Year".
- **Rating**: Set minimum and/or maximum IMDb ratings.
- **Votes**: Specify the minimum number of votes.
- **Director**: Filter by director's name.
- **Writer**: Filter by writer's name.
- **Genre**: Select a specific genre.
- **Language**: Translate the title of movies into the selected language.
- **Adult**: Include or exclude adult content.

**Note**: Multiple filters can be applied simultaneously to narrow down your search results.

## Setup Instructions
To set up and run the application, follow these steps:
1. Install [Docker](https://www.docker.com/).
2. Clone the repository containing this project to your local machine.
3. Navigate to the project directory in your terminal.
4. Run the following command to start the application:

```bash
docker-compose up --build
```

5. Open your browser and navigate to `http://localhost:5000` to use the application.

## Usage
1. **Homepage**:
- Landing page with
- A button to refresh data 
- And another to start browsing the movies.

2. **Search Page**:
- Use the filters in the search box to find movies.
- Translate movie titles into the selected language.
- Toggle adult mode with a checkbox.
- Results are displayed below the search box, with pagination enabled.

3. **Movie Details Page**:
- View detailed information about a specific movie.

## Refreshing Data
The "Refresh Data" button on the homepage triggers scripts to update the movie database with the latest data from IMDb. Refreshing is required for initial setup on each machine. 

## Lowest hardware requirement
At least 64GB of RAM. Refreshing data requires at least 48GB of RAM designated to WSL 2 backend on Windows. This software has not been tested on macOS and is not guaranteed to work on machines with less than 64GB of RAM. 

## Data Source
The data used in this project is sourced from the [IMDb Non-Commercial Datasets](https://developer.imdb.com/non-commercial-datasets/).

## Generative AI Usage Disclosure
ChatGPT was used in the development of this project for both coding and documentation. 