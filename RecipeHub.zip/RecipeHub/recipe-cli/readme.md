# Recipe CLI Project

A powerful command-line interface for managing and analyzing recipe data, featuring advanced search capabilities, nutritional analysis, and personalized recommendations.

## Features

- Recipe search by ingredients, cuisine type, and cooking time
- Nutritional analysis and dietary pattern tracking
- Review sentiment analysis
- Personalized recipe recommendations
- Trend analysis and seasonal patterns
- Support for dietary restrictions
- Similar recipe finder

## Prerequisites

- Docker and Docker Compose
- Git (for cloning the repository)
- Internet connection (for initial data download)

## Setup and Installation

### 1. Start Docker Containers

First, launch the MongoDB and Python containers using Docker Compose:

```bash
docker-compose up -d
```

This will start:
- MongoDB container (exposed on port 27017)
- Python container with all required dependencies

### 2. Initialize the Database (IMPORTANT)

Before running the main application, you must first initialize the database with recipe data. This is a crucial step that only needs to be done once:

```bash
# Access the Python container
docker exec -it recipe-cli bash

# Run the data creation script
python data-creation.py
```

This script will:
- Download the Food.com dataset from Kaggle
- Process and clean the raw data
- Create necessary MongoDB indexes
- Calculate recipe statistics
- Generate initial recommendations

⚠️ **Important**: Do not skip this step! The main application will not work properly without the initialized database.

### 3. Run the Application

After the database is initialized, you can run the main application:

```bash
# From within the Python container
python app.py
```


## Using the CLI

Once the application is running, you can use the following commands:

### Basic Queries
- `search <ingredient/recipe name>` - Search recipes by name or ingredients
- `time <minutes>` - Find recipes taking less than specified minutes
- `cuisine <type>` - Search recipes by cuisine type

### Nutritional Queries
- `nutrition <nutrient> <max_value>` - Find recipes by nutritional criteria
- `analyze_nutrition [user_id]` - Analyze nutritional patterns

### Recommendations and Similar Recipes
- `similar <recipe_id>` - Find similar recipes
- `recommend <user_id>` - Get personalized recommendations

### Analysis
- `trends [days=30]` - Analyze recipe trends
- `sentiment <recipe_name>` - Detailed sentiment analysis
- `diet <restriction>` - Find recipes by dietary restriction

Add `--limit N` to any command to change the number of results (default: 5)

## Project Structure

- `app.py` - Main CLI application entry point
- `recipe_app.py` - Core application logic and database operations
- `data-creation.py` - Database initialization and data processing
- `formatters.py` - Output formatting utilities
- `docker-compose.yml` - Docker configuration

## Troubleshooting

1. If you encounter MongoDB connection errors:
   - Ensure MongoDB container is running: `docker ps`
   - Check MongoDB logs: `docker logs mymongo`

2. If no recipes are found:
   - Verify the database was initialized: `python data-creation.py`
   - Check MongoDB data exists: Connect to mongo container and verify collections

3. If you get import errors:
   - Ensure you're running commands from within the Python container
   - Verify all dependencies are installed
