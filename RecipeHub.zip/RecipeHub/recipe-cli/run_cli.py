print("Starting Recipe CLI...", flush=True)

from app import main

print("Initializing application...", flush=True)
main()
print("Application terminated.", flush=True)
