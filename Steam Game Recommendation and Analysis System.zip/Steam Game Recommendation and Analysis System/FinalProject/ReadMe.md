# Final Project: Steam Game Recommendation and Analysis System

## Summary

The Steam Game Recommendation and Analysis System is a Flask-based web application that allows users to explore, analyze, and retrieve insights about Steam games and user reviews. The app integrates with MongoDB to handle large datasets efficiently and provides seven query options for filtering and analyzing data, such as finding games by platform, tags, release year, and user review history.

## Why MongoDB?
We chose MongoDB for this project due to its flexibility, efficiency, and ability to handle semi-structured data. Key reasons for using MongoDB include:

- Flexible Schema:

Steam game data consists of nested and hierarchical fields such as tags, platforms, and pricing. MongoDB's document-oriented structure is ideal for representing this type of data.

- Efficient Querying:

MongoDB's powerful querying and indexing capabilities allow for fast and efficient retrieval of data, even for complex filters and aggregations.

- Aggregation Framework:

MongoDB's aggregation pipeline simplifies complex queries, such as joining collections ($lookup) and performing grouping or sorting operations.

## Schema

### Games Collection
The `games` collection contains detailed information about each game available on Steam.
![My Image](1-1.png)

---

### Users Collection
The `users` collection contains summary information about each user.
![My Image](1-2.png)

---

### Reviews Collection
The `reviews` collection contains detailed information about game reviews submitted by users.
![My Image](1-3.png)


## Data Transformation

The script involves transforming and merging datasets into structured JSON files that match the predefined schemas for MongoDB integration. First, the games.csv and games_metadata.json files are loaded and merged on the app_id field to combine game attributes with metadata like descriptions and tags. The merged dataset is then transformed into a hierarchical JSON structure that includes fields like platforms, pricing, and tags. This structure ensures compatibility with MongoDB's document-oriented design. Similarly, the users.csv and recommendations.csv datasets are loaded and converted to JSON files. All transformed data is saved as structured JSON files (games.json, users.json, recommendations.json), making them ready for insertion into MongoDB.

### Data source
The data will be sourced from Kaggle. https://www.kaggle.com/datasets/antonkozyriev/game-recommendations-on-steam/data
The datasets are very big so they cannot be uploaded to gradescope. To rerun the code, you can download the original dataset from kaggel and run the data_transform notebook.

## Setup Instructions

Follow these steps to set up and run the Steam Game Recommendation and Analysis System:


### Step 1: Start the Docker Container
1. Open the Docker app.
2. Open a terminal and navigate to the directory containing the `docker-compose.yml` file.
3. Run the following command to set up and start the Docker container: `docker compose up`

### Step 2: Access the Docker Container
1. Open another terminal tab and use the following command to access the Docker container: `docker compose exec -it mongodb sh`

### Step 3: Import Data into MongoDB

1. Use the following commands to import the JSON files into MongoDB:

`mongoimport --db mydb --collection games --file /ds5760/mongo/game_data/games.json --jsonArray`

`mongoimport --db mydb --collection users --file /ds5760/mongo/game_data/users.json --jsonArray`

`mongoimport --db mydb --collection reviews --file /ds5760/mongo/game_data/recommendations.json --jsonArray`

Example:
![My Image](2.png)

### Step 4: Create Indexes
To speed up data retrieval and optimize sorting and filtering for our queries, create indexes for each collection:
 
1. Open the MongoDB Shell and Run the following command in your terminal to access the MongoDB shell:
`docker compose exec -it mongodb mongosh`

2. Switch to the Database by running: `use mydb`

3. create indexes by runing the following commands:

`db.games.createIndex({ "platforms.win": 1, "platforms.mac": 1, "platforms.linux": 1, "positive_ratio": -1 });`

`db.games.createIndex({ "tags": 1, "positive_ratio": -1 });`

`db.games.createIndex({ "date_release": 1, "positive_ratio": -1 });`

`db.games.createIndex({ "price.final": 1, "positive_ratio": -1 });`

`db.games.createIndex({ "price.discount": -1, "tags": 1 });`

`db.reviews.createIndex({ "user_id": 1, "is_recommended": 1 });`

`db.reviews.createIndex({ "app_id": 1 });`

### Step 5: Run the application
1. Navigate to the directory that has the `app.py` file and run the application with the command: `python app.py`.
2. To access the Application: Open your browser and navigate to http://127.0.0.1:5000

## Queries Overview

The application provides the following seven queries, each designed to answer specific user needs:
![My Image](overview.png)

### 1. Top Games by Platforms
**Description**:  
Find the top-rated games that are compatible with specific platforms (Windows, Mac, Linux). The user can filter by platform and specify the number of results.

**Purpose**:  
This query helps users identify the best games that work on their operating system.

![My Image](3.png)

### 2. Top Games by Tags
**Description**:  
Search for the top-rated games based on a specific tag (e.g., "Action", "Adventure"). The user can perform a case-insensitive search and set the number of results.

**Purpose**:  
Allows users to explore games in specific categories or genres they are interested in.

![My Image](4.png)

### 3. Games Released After a Certain Date
**Description**:  
Find games released after a specified date, sorted by their release date. The user can specify the date and the number of results.

**Purpose**:  
Useful for users who want to find recent releases or explore games within a specific timeframe.

![My Image](5.png)

### 4. Top Games by Release Year
**Description**:  
Find the top-rated games released in a specific year. Users can input the year and the number of results.

**Purpose**:  
Helps users identify the most popular games for a specific year, useful for retrospectives or catching up on past hits.

![My Image](6.png)

### 5. Games in a Specific Price Range
**Description**:  
Search for games within a specified price range, sorted by their positive review ratio. Users can input the minimum and maximum price along with the number of results.

**Purpose**:  
Helps users find games that fit their budget while still having good reviews.

![My Image](7.png)

### 6. Games with the Highest Discount by Tag
**Description**:  
Find games with the highest discounts in a specific tag (e.g., "Strategy", "Indie"). Users can input the tag and the number of results.

**Purpose**:  
Allows users to discover the best deals on games in their preferred categories.

![My Image](8.png)

### 7. User Game Recommendation Review History
**Description**:  
Retrieve a user’s game review history for games they recommended (`is_recommended = true`). Displays the game title, review date, hours played, and helpful and funny votes.

**Purpose**:  
Allows users to review their personal recommendation history or analyze another user's preferences.

![My Image](9.png)