from flask import Flask, jsonify, request, render_template
from pymongo import MongoClient

# Initialize the Flask application
app = Flask(__name__)

# MongoDB setup
# Connect to the MongoDB client
client = MongoClient(host="localhost", port=27017)

# Select the database
db = client.mydb  # 'use mydb' equivalent in MongoDB shell


# Home Page with Buttons for Each Query
@app.route('/')
def home():
    """
    Renders the home page with navigation buttons for each query.
    """
    return render_template('index.html')


# Query 1: Find Top Games Compatible with Specific Platforms
@app.route('/query1', methods=['GET', 'POST'])
def query1():
    """
    Allows the user to filter games based on platform compatibility (Windows, Mac, Linux).
    The user can also choose the number of results to display.
    """
    if request.method == 'POST':
        # Get user inputs from the form
        win = request.form.get('windows') == 'on'
        mac = request.form.get('mac') == 'on'
        linux = request.form.get('linux') == 'on'
        limit = int(request.form.get('limit', 10))

        # Build the query filter for platforms
        platform_filter = {}
        if win:
            platform_filter["platforms.win"] = True
        if mac:
            platform_filter["platforms.mac"] = True
        if linux:
            platform_filter["platforms.linux"] = True

        # Query the database
        result = db.games.find(
            platform_filter,
            {"_id": 0, "app_id": 1, "title": 1, "description": 1, "tags": 1, "price.final": 1, "positive_ratio": 1}
        ).sort("positive_ratio", -1).limit(limit)

        # Convert results to a list
        games = list(result)
        return render_template('query1.html', games=games)

    # Render the form for GET request
    return render_template('query1.html', games=None)


# Query 2: Find Top Games by Tags
@app.route('/query2', methods=['GET', 'POST'])
def query2():
    """
    Allows the user to search for games by tag (e.g., "Action", "Adventure").
    The search is case-insensitive, and users can specify the number of results.
    """
    if request.method == 'POST':
        # Get user input for tag and limit from the form
        tag = request.form.get('tag', '').strip()
        limit = int(request.form.get('limit', 10))

        # Query the database (case-insensitive tag search)
        result = db.games.find(
            {"tags": {"$regex": tag, "$options": "i"}},  # Case-insensitive search
            {"_id": 0, "title": 1, "description": 1, "tags": 1, "price.final": 1, "positive_ratio": 1}
        ).sort("positive_ratio", -1).limit(limit)

        # Convert results to a list
        games = list(result)
        return render_template('query2.html', games=games, tag=tag)

    # Render the form for GET request
    return render_template('query2.html', games=None, tag=None)


# Query 3: Find Games Released After a Certain Date
@app.route('/query3', methods=['GET', 'POST'])
def query3():
    """
    Allows the user to find games released after a specified date.
    Users can also choose the number of results to display.
    """
    if request.method == 'POST':
        # Get user input for date and limit from the form
        date = request.form.get('date', '2022-01-01').strip()
        limit = int(request.form.get('limit', 10))

        # Query the database
        result = db.games.find(
            {"date_release": {"$gte": date}},
            {"_id": 0, "title": 1, "description": 1, "tags": 1, "price.final": 1, "date_release": 1, "positive_ratio": 1}
        ).sort("date_release", 1).limit(limit)

        # Convert results to a list
        games = list(result)
        return render_template('query3.html', games=games, date=date)

    # Render the form for GET request
    return render_template('query3.html', games=None, date=None)


# Query 4: Find Top Games by Release Year
@app.route('/query4', methods=['GET', 'POST'])
def query4():
    """
    Allows the user to find games released in a specific year, sorted by positive review ratio.
    Users can also specify the number of results to display.
    """
    if request.method == 'POST':
        # Get user input for year and limit from the form
        year = request.form.get('year', '').strip()
        limit = int(request.form.get('limit', 10))

        # Build the query filter
        start_date = f"{year}-01-01"
        end_date = f"{year}-12-31"

        # Query the database
        result = db.games.find(
            {"date_release": {"$gte": start_date, "$lte": end_date}},
            {"_id": 0, "title": 1, "description": 1, "tags": 1, "price.final": 1, "positive_ratio": 1}
        ).sort("positive_ratio", -1).limit(limit)

        # Convert results to a list
        games = list(result)
        return render_template('query4.html', games=games, year=year)

    # Render the form for GET request
    return render_template('query4.html', games=None, year=None)


# Query 5: Find Games in a Specific Price Range
@app.route('/query5', methods=['GET', 'POST'])
def query5():
    """
    Allows the user to search for games within a specified price range.
    Users can also choose the number of results to display.
    """
    if request.method == 'POST':
        # Get user input for price range and limit from the form
        min_price = float(request.form.get('min_price', 0))
        max_price = float(request.form.get('max_price', 100))
        limit = int(request.form.get('limit', 10))

        # Query the database
        result = db.games.find(
            {"price.final": {"$gte": min_price, "$lte": max_price}},
            {"_id": 0, "title": 1, "description": 1, "tags": 1, "price.final": 1, "positive_ratio": 1}
        ).sort("positive_ratio", -1).limit(limit)

        # Convert results to a list
        games = list(result)
        return render_template('query5.html', games=games, min_price=min_price, max_price=max_price)

    # Render the form for GET request
    return render_template('query5.html', games=None, min_price=None, max_price=None)


# Query 6: Find Games with the Highest Discount by Tag
@app.route('/query6', methods=['GET', 'POST'])
def query6():
    """
    Allows the user to search for games with the highest discount within a specific tag.
    Users can also specify the number of results to display.
    """
    if request.method == 'POST':
        # Get user input for tag and limit from the form
        tag = request.form.get('tag', '').strip()
        limit = int(request.form.get('limit', 10))

        # Query the database (filter by tag and sort by discount)
        result = db.games.find(
            {"tags": {"$regex": tag, "$options": "i"}},  # Case-insensitive tag search
            {"_id": 0, "title": 1, "description": 1, "tags": 1, "price.final": 1, "price.discount": 1, "positive_ratio": 1}
        ).sort("price.discount", -1).limit(limit)

        # Convert results to a list
        games = list(result)
        return render_template('query6.html', games=games, tag=tag)

    # Render the form for GET request
    return render_template('query6.html', games=None, tag=None)

# Query 7: User Game Recommendation Review History
@app.route('/query7', methods=['GET', 'POST'])
def query7():
    """
    Allows the user to search for their game recommendation review history.
    Retrieves reviews where 'is_recommended' is true, including game details like title.
    Displays the review date, hours played, helpful votes, and funny votes.
    """
    if request.method == 'POST':
        # Get user input for user_id from the form
        user_id = int(request.form.get('user_id', '0').strip())

        # Query the database for reviews where is_recommended is true
        result = db.reviews.aggregate([
            {"$match": {"user_id": user_id, "is_recommended": True}},  # Filter for specific user_id and recommended reviews
            {
                "$lookup": {
                    "from": "games",  # Join with games collection to get game titles
                    "localField": "app_id",
                    "foreignField": "app_id",
                    "as": "game_details"
                }
            },
            {
                "$project": {  # Select only relevant fields to display
                    "game_details.title": 1,  # Include game title from joined data
                    "date": 1,
                    "hours_played": 1,
                    "helpful": 1,
                    "funny": 1
                }
            }
        ])

        # Convert results to a list
        reviews = list(result)
        return render_template('query7.html', reviews=reviews, user_id=user_id)

    # Render the form for GET request
    return render_template('query7.html', reviews=None, user_id=None)


# Run the Application
if __name__ == '__main__':
    app.run(debug=True)